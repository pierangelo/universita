package applicazione;

import playlist.*;
import brano.*;

import java.util.*;

public final class Stampa {
    public static void stampaBrani(PlayList p) {
        System.out.println("LA PLAYLIST " + p.getNome() +
                           " CONTIENE I SEGUENTI BRANI:");
        List<Brano> temp = p.getLinkContiene();
        Iterator<Brano> it = temp.iterator();
        while(it.hasNext()) {
            Brano b = it.next();
            System.out.println(b.getNome());
        }
	System.out.println("DURATA TOTALE: " + p.durataTotale());
    }
    private Stampa() { }
}
