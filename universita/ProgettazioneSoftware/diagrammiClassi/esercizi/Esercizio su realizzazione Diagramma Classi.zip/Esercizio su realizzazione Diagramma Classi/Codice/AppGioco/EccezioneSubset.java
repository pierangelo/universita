package AppGioco;

public class EccezioneSubset extends RuntimeException {
	private String messaggio;

	public EccezioneSubset(String m) {
		messaggio = m;
	}

	public EccezioneSubset() {
		messaggio = "Si e' verificata una violazione del vincolo di subset";
	}

	public String toString() {
		return messaggio;
	}
}
