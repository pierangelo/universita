package AppGioco;

public final class ManagerDedicatoA {
	private ManagerDedicatoA(TipoLinkDedicatoA x) {
		link = x;
	}

	private TipoLinkDedicatoA link;

	public TipoLinkDedicatoA getLink() {
		return link;
	}

	public static void inserisci(TipoLinkDedicatoA y) {
		if (y != null && !y.getQuadroDedicato().estPresenteLinkDedicatoA()) {
			ManagerDedicatoA k = new ManagerDedicatoA(y);
			k.link.getQuadroDedicato().inserisciPerManagerDedicatoA(k);
			k.link.getPersonaggio().inserisciPerManagerDedicatoA(k);
		}
	}

	public static void elimina(TipoLinkDedicatoA y) {
		if (y != null) {
			ManagerDedicatoA k = new ManagerDedicatoA(y);
			k.link.getQuadroDedicato().eliminaPerManagerDedicatoA(k);
			k.link.getPersonaggio().eliminaPerManagerDedicatoA(k);
		}
	}
}
