package AppGioco;

public class EccezioneMolteplicita extends RuntimeException {
	private String messaggio;

	public EccezioneMolteplicita(String m) {
		messaggio = m;
	}

	public EccezioneMolteplicita() {
		messaggio = "Si e' verificata una violazione delle molteplicit�";
	}

	public String toString() {
		return messaggio;
	}
}
