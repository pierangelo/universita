package AppGioco;

public final class ManagerGiocato {
	private ManagerGiocato(TipoLinkGiocato x) {
		link = x;
	}

	private TipoLinkGiocato link;

	public TipoLinkGiocato getLink() {
		return link;
	}

	public static void inserisci(TipoLinkGiocato y) {
		if (y != null) {
			ManagerGiocato k = new ManagerGiocato(y);
			k.link.getQuadro().inserisciPerManagerGiocato(k);
			k.link.getPartita().inserisciPerManagerGiocato(k);
		}
	}

	public static void elimina(TipoLinkGiocato y) {
		if (y != null) {
			ManagerGiocato k = new ManagerGiocato(y);
			k.link.getQuadro().eliminaPerManagerGiocato(k);
			k.link.getPartita().eliminaPerManagerGiocato(k);
		}
	}
}
