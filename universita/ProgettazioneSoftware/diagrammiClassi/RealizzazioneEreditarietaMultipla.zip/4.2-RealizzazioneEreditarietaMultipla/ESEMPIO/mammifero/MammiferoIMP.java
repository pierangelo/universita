package mammifero;

import animale.*;

public class MammiferoIMP implements Mammifero {
	  private AnimaleIMP animale;	//NOTA!
	  private int mesi_di_gestazione;
	  public MammiferoIMP(String g, String s, String c, int m) {
	    animale = new AnimaleIMP("Mammifero",g,s,c);
	    mesi_di_gestazione = m;
	  }
	  public String getOrdine() {  //NOTA!
	    return animale.getOrdine();  
	  }
	  public String getGenere() { //NOTA!
	    return animale.getGenere();
	  }
	  public String getSpecie() { //NOTA!
	    return animale.getSpecie();
	  }
	  public String getCiboPreferito() { //NOTA!
	    return animale.getCiboPreferito();
	  }
	  public int getMesiDiGestazione() { return mesi_di_gestazione; }
	}
