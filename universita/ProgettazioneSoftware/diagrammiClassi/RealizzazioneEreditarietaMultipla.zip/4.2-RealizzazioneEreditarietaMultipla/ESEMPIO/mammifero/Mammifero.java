package mammifero;

import animale.*;

public interface Mammifero extends Animale {
  public int getMesiDiGestazione();
}
