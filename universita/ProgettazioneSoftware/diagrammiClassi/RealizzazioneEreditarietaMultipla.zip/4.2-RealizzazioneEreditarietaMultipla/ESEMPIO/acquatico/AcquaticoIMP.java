package acquatico;

import animale.*;

public class AcquaticoIMP implements Acquatico {
	private AnimaleIMP animale; // NOTA!
	private float max_salinita_acqua;

	public AcquaticoIMP(String o, String g, String s, String c, float m) {
		animale = new AnimaleIMP(o, g, s, c);
		max_salinita_acqua = m;
	}

	public String getOrdine() { // NOTA!
		return animale.getOrdine();
	}

	public String getGenere() { // NOTA!
		return animale.getGenere();
	}

	public String getSpecie() { // NOTA!
		return animale.getSpecie();
	}

	public String getCiboPreferito() { // NOTA!
		return animale.getCiboPreferito();
	}

	public float getMaxSalinitaAcqua() {
		return max_salinita_acqua;
	}
}
