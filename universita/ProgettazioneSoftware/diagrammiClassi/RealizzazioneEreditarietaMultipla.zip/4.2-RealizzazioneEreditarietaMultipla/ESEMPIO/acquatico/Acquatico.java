package acquatico;

import animale.*;

public interface Acquatico extends Animale {
  public float getMaxSalinitaAcqua();
}

