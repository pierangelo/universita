package animale;

public interface Animale {
  public String getOrdine();
  public String getGenere();
  public String getSpecie();
  public String getCiboPreferito();
}

