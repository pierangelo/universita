package thread6esempioContatoreCondiviso;

public class ProcessoConta implements Runnable {
	private Contatore contatore;

	public ProcessoConta(Contatore c) {
		contatore = c;
	}

	public void run() {
		for (int i = 0; i < 10; i++) {
			contatore.incrementa();
			try { Thread.sleep(10);
			} catch (InterruptedException ex) {}
			System.out.println(
					Thread.currentThread().getName() +
					": il contatore segna " + contatore.getValore());
		}
	}
	

}
