package thread6esempioContatoreCondiviso;

public class Contatore {
	private int valore;

//	aggiungere synchronized! 
//	public synchronized void incrementa() {	
	public void incrementa() {	
		int tmp = valore;
		try { Thread.sleep(10);
		} catch (InterruptedException ex) {}
		valore = tmp + 1;
	}
	
	public int getValore() {
//	public synchronized int getValore() {
		return valore;
	}

}
