package thread6esempioContatoreCondiviso;

public class Main {
	public static void main(String[] args) {
		Contatore cnt = new Contatore();
		Thread a = new Thread(new ProcessoConta(cnt));
		Thread b = new Thread(new ProcessoConta(cnt));
		a.start();
		b.start();
	}
}
