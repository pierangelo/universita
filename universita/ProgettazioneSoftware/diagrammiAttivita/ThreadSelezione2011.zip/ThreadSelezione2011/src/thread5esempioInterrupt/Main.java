package thread5esempioInterrupt;

public class Main {
	public static void main(String[] args) {
		SleepInterrupt si = new SleepInterrupt();
		Thread t = new Thread(si);
		t.start();

		// Be sure that the new thread gets a chance to run for a while
		try {
			Thread.sleep(2000);
		} catch (InterruptedException x) {
		}

		System.out.println("in main() - interrupting other thread");
		t.interrupt();
		System.out.println("in main() - leaving");
	}
}
