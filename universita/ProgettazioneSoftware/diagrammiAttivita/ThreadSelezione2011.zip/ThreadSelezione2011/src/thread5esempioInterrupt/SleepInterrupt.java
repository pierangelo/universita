package thread5esempioInterrupt;

public class SleepInterrupt implements Runnable {
	public void run() {
		try {
			System.out.println("in run()");
			Thread.sleep(20000);
			System.out.println("in run() - woke up");
		} catch (InterruptedException x) {
			System.out.println("in run() - interrupted while sleeping");
			return;
		}
		System.out.println("fine");
	}
}
