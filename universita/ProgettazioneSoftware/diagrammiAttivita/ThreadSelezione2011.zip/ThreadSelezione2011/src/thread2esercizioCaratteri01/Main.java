package thread2esercizioCaratteri01;

public class Main {

    public static void main(String[] args) {
        Thread t1 = new Thread(new PrintExecutable('0'));
        Thread t2 = new Thread(new PrintExecutable('1'));
        t1.start();
        t2.start();
    }
}
