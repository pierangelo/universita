package thread2esercizioCaratteri01;

public class PrintExecutable implements Runnable {
    private final char c;

    public PrintExecutable(char c) {
        this.c = c;
    }

    public void run() {
        for (int i=0;i<100;i++){
            System.out.print(c);
            try {
            	  Thread.sleep((long)(Math.random() * 10));
            } catch (InterruptedException e) {}
        }
    }

}
