package thread8queue3;

public class Producer implements Runnable {

	private String greeting;
	private BoundedQueue<String> queue;
	private int greetingCount;

	private static final int DELAY = 10;

	public Producer(String aGreeting, BoundedQueue<String> aQueue, int count) {
		greeting = aGreeting;
		queue = aQueue;
		greetingCount = count;
	}

	public void run() {
		try {
			int i = 1;
			while (i <= greetingCount) {
				queue.add(i + ": " + greeting);
				i++;
				Thread.sleep((int) (Math.random() * DELAY));
			}
		} catch (InterruptedException exception) {
		}
	}
}
