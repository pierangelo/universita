package thread8queue1;

import java.util.ArrayList;
import java.util.List;

public class BoundedQueue {

	private List<Object> elements;
	private int maxSize;

	public BoundedQueue(int capacity) {
		elements = new ArrayList<Object>();
		maxSize = capacity;
	}

	// * @precondition !isEmpty()
	public Object remove() {
		if (elements.isEmpty())
			System.out.println("ERR: la coda � vuota! -------------------");
		Object r = elements.remove(0);
		System.out.println(Thread.currentThread().getName() + ": remove, size=" + elements.size());
		return r;
	}

	// * @precondition !isFull();
	public void add(Object newObj) {
		if (elements.size() >= maxSize)
			System.out.println("ERR: la coda � piena! ++++++++++++++++++++");
		elements.add(newObj);
		System.out.println(Thread.currentThread().getName() + ": add, size=" + elements.size());
	}

	public boolean isFull() {
		return elements.size() >= maxSize;
	}

	public boolean isEmpty() {
		return elements.isEmpty();
	}

}
