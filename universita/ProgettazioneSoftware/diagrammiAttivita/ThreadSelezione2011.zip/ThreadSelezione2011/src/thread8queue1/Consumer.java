package thread8queue1;

public class Consumer implements Runnable {

	private BoundedQueue queue;
	private int greetingCount;

	private static final int DELAY = 10;
	

	public Consumer(BoundedQueue aQueue, int count) {
		queue = aQueue;
		greetingCount = count;
	}

	public void run() {
		try {
			int i = 1;
			while (i <= greetingCount) {
				if (!queue.isEmpty()) {
					Object greeting = queue.remove();
					System.out.println(greeting);
					i++;
				}
				Thread.sleep((int) (Math.random() * DELAY));
			}
		} catch (InterruptedException exception) {
		}
	}
}
