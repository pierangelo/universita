package thread4countdown;

public class MainSequenziale {
	public static void main(String[] args) {
		CountDown h = new CountDown("Huston", 10);
		CountDown c = new CountDown("CapeCanaveral", 10);
		h.run(); // NB invoco h.run() sul thread del main
		c.run(); // NB invoco c.run() sul thread del main
		System.out.println("Si parte!!!");
	}
}
