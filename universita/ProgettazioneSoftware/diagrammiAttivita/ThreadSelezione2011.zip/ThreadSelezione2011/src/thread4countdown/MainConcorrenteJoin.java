package thread4countdown;

public class MainConcorrenteJoin {
	public static void main(String[] args) {
		CountDown h = new CountDown("Huston", 10);
		CountDown c = new CountDown("CapeCanaveral", 10);
		Thread t1 = new Thread(h);
		Thread t2 = new Thread(c);
		t1.start(); // NB invoco h.run() sul thead t1
		t2.start(); // NB invoco c.run() sul thead t2
		try {
			t1.join();
		} catch (InterruptedException e) {
			// qui va codice da eseguire se il main viene risvegliato da un interrupt
			// prima di aver fatto join
		}
		System.out.println("Si parte!!!");
	}
}
