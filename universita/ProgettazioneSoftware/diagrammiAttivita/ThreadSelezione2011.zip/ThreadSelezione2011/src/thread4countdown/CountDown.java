package thread4countdown;

public class CountDown implements Runnable {
	private String id;
	private int countDown;

	public CountDown(String nome, int countDownPartenza) {
		id = nome;
		countDown = countDownPartenza;
	}

	public String status() {
		return id + ": " + (countDown > 0 ? countDown : "Go!") + "\n";
	}

	public void run() {
		while (countDown >= 0) {
			System.out.print(status());
			countDown--;
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
	}
}
