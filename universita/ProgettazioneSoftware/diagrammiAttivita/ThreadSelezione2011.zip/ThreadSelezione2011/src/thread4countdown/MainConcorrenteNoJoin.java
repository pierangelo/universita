package thread4countdown;

public class MainConcorrenteNoJoin {
	public static void main(String[] args) {
		CountDown h = new CountDown("Huston", 10);
		CountDown c = new CountDown("CapeCanaveral", 10);
		Thread t1 = new Thread(h);
		Thread t2 = new Thread(c);
		t1.start(); // NB invoco h.run() sul thread t1
		t2.start(); // NB invoco c.run() sul thread t2
		System.out.println("Si parte!!!");
	}
}
