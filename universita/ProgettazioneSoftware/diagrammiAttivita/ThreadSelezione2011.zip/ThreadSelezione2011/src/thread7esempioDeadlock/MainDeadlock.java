package thread7esempioDeadlock;

public class MainDeadlock {
    public static void main(String[] args) throws InterruptedException {
    	Risorsa r1 = new Risorsa("alfa",5);
    	Risorsa r2 = new Risorsa("beta", 20);
    	System.out.println(Thread.currentThread().getName() + " begins");
    	Confronto c1 = new Confronto(r1,r2);
        Confronto c2 = new Confronto(r2,r1);
        Thread t1 = new Thread(c1); //t1.setDaemon(true);
        Thread t2 = new Thread(c2); //t2.setDaemon(true);
        t1.start();
        t2.start();
        Thread.sleep(10000);
        System.out.println(Thread.currentThread().getName() + " ends");
    }
}
