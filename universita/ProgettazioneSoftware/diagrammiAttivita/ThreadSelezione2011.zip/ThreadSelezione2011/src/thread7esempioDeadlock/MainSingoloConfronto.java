package thread7esempioDeadlock;

public class MainSingoloConfronto {
	public static void main(String[] args) throws InterruptedException {
		Risorsa r1 = new Risorsa("alpha",5);
		Risorsa r2 = new Risorsa("beta",20);
		System.out.println(Thread.currentThread().getName() + " begins");
		Confronto c1 = new Confronto(r1, r2);
		Thread t1 = new Thread(c1);
		t1.start();
		Thread.sleep(10000); //aspetta 10 sec 
		System.out.println(Thread.currentThread().getName() + " ends");
	}
}