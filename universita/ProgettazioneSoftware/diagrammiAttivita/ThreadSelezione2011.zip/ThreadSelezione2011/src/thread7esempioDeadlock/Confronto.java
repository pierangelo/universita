package thread7esempioDeadlock;

public class Confronto implements Runnable {
	Risorsa r1;
	Risorsa r2;

	Confronto(Risorsa r1, Risorsa r2) {
		this.r1 = r1;
		this.r2 = r2;
	}

	public void run() {
		System.out.println(Thread.currentThread().getName() + " begins");
		Risorsa rm = r1.maxVal(r2);
		String rn = rm.getNome();
		System.out.println(Thread.currentThread().getName()
					+ ": la risorsa pi� grande � " + rn);
		System.out.println(Thread.currentThread().getName() + " ends");
	}

}
