package thread7esempioDeadlock;

public class Risorsa {
	private String nome;
	private int valore;

	Risorsa(String id, int v) {
		nome = id;
		valore = v;
	}

	public synchronized int getValore() {
		return valore;
	}

	public synchronized String getNome() {
		return nome;
	}

	public synchronized Risorsa maxVal(Risorsa ra) {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
		}
		int va = ra.getValore();
		if (valore >= va)
			return this;
		else
			return ra;
	}
}
