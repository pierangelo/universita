package thread8queue2;

public class ThreadTester {
	public static void main(String[] args) {
		BoundedQueue queue = new BoundedQueue(10);
		final int GREETING_COUNT = 1000;
		Runnable run1 = new Producer("Hello, World!", queue, GREETING_COUNT);
		Runnable run2 = new Producer("Goodbye, World!", queue, GREETING_COUNT);
		Runnable run3 = new Consumer(queue, GREETING_COUNT);
		Runnable run4 = new Consumer(queue, GREETING_COUNT);

		Thread thread1 = new Thread(run1);
		Thread thread2 = new Thread(run2);
		Thread thread3 = new Thread(run3);
		Thread thread4 = new Thread(run4);
		thread1.start();
		thread2.start();
		thread3.start();
		thread4.start();
	}
}

