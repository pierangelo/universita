package thread1primoEsempio;

public class Main {
	public static void main(String[] args) {
		MiaClasseRunnable ja = new MiaClasseRunnable("Jamaica");
		Thread mioThread = new Thread(ja);
		mioThread.start();
	}
}
