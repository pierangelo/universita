package thread1primoEsempioISA;

public class Main {
	public static void main(String[] args) {
		MiaClasseThread jat = new MiaClasseThread("Jamaica");
		jat.start();
	}
}
