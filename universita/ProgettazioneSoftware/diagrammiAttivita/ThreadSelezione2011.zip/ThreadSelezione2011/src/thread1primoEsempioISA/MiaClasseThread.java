package thread1primoEsempioISA;

public class MiaClasseThread extends Thread {
	private String nome;

	MiaClasseThread(String n) {
//		super();
		nome = n;
	}

	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(nome + ": " + i);
		}
		System.out.println(nome + ": DONE! ");
	}
}
