package attivita_atomiche;

import contiene.*;
import giocatore.*;
import gara.*;
import java.util.*;

import squadra.*;

public final class Stampa {
    public static void stampaSquadra(Squadra s) {
        System.out.println("Squadra: " + s.getNome() +
                           " contiene i seguenti giocatori");
        Iterator<TipoLinkContiene> it = s.getLinkContiene().iterator();
        while(it.hasNext()) {
            Giocatore gs = it.next().getGiocatore();
            System.out.println("Giocatore: " + gs.getNome() + ", " + gs.getVelocita());
        }
        System.out.println("Squadra: " + s.getNome() + " completa");
    }
    
    public static void stampaGara(Gara g) {
        System.out.println("Gara: " + g.getNome() +
                           " contiene le seguenti squadre");
        Iterator<Squadra> it = g.getLinkPartecipa().iterator();
        int i = 0;
        while(it.hasNext()) {
            Squadra s = it.next();
            System.out.println("Squadra" + i);
            i++;
            stampaSquadra(s);
        }   
    }
    
    private Stampa() { }
}
