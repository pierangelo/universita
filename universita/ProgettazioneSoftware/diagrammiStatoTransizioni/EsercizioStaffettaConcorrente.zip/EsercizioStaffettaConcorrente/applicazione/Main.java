package applicazione;

import attivita_composte.*;

public class Main {
	public static void main(String[] args) throws InterruptedException {
		Thread attivitaPrincipale = new Thread(new AttivitaPrincipale());
		attivitaPrincipale.start();
	}
}
