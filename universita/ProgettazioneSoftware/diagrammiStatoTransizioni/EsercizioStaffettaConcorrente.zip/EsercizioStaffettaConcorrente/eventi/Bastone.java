package eventi;

import _gestioneeventi.*;

public class Bastone extends Evento {
	public double trattoPercorso;
    public Bastone(Listener m, Listener d) {
    	super(m,d);
    }
    public boolean equals(Object o) {
        return super.equals(o);
    }
   public int hashCode() {
       return super.hashCode() + getClass().hashCode();  
    }
    public String toString() {
    	return "Bastone(" + getMittente() + " -> " + getDestinatario() + ")";
    } 
}


