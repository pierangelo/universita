package applicazione;

import playlist.*;
import player.*;
import _gestioneeventi.*;
import brano.*;
import contiene.*;
import eventi.*;

public final class Main {
	public static void main(String[] args) {
		Brano b1 = new Brano("Blackbird", 314, "Musica/blackbird.mp3"), b2 = new Brano(
				"Hang Up", 520, "Musica/hangup.mp3"), b3 = new Brano(
				"Tangled up in blue", 810, "Musica/tangled.mp3"), b4 = new Brano(
				"Big Jig in the Sky", 335, "Musica/Jig.mp3");
		PlayList pl = new PlayList("PlayListSonia");

		ManagerContiene.inserisci(new TipoLinkContiene(pl, b1));
		ManagerContiene.inserisci(new TipoLinkContiene(pl, b2));
		ManagerContiene.inserisci(new TipoLinkContiene(pl, b3));
		ManagerContiene.inserisci(new TipoLinkContiene(pl, b4));

		Stampa.stampaBrani(pl);

		System.out.println("INIZIO ESECUZIONE");
		esegui(pl);
		System.out.println("FINE ESECUZIONE");
	}

	private static void esegui(PlayList playlist) {
		Player player = new Player();
		Environment env = new Environment();
		env.addListener(playlist);
		env.addListener(player);
		env.aggiungiEvento(new Play(null, playlist, player));
		env.eseguiEnvironment();
	}

	private Main() {
	}
}
