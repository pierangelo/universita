package applicazione;

import playlist.*;
import brano.*;
import contiene.*;

import java.util.*;

public final class Stampa {
    public static void stampaBrani(PlayList p) {
        System.out.println("La playList " + p.getNome() +
                           " contiene i seguenti brani:");
        List<TipoLinkContiene> temp = p.getLinkContiene();
        Iterator<TipoLinkContiene> it = temp.iterator();
        while(it.hasNext()) {
            Brano b = it.next().getBrano();
            System.out.println(b.getNome());
        }
    }
    private Stampa() { }
}
