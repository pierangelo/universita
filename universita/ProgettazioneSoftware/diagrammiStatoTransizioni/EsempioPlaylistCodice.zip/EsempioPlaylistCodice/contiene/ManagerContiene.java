package contiene;

import playlist.*;

public final class ManagerContiene {
    private ManagerContiene(TipoLinkContiene x) { link = x; }
    private TipoLinkContiene link;
    public TipoLinkContiene getLink() { return link; }
    public static void inserisci(TipoLinkContiene y) {
        if (y != null) {
	    if (y.getPlayList().getStato() != PlayList.Stato.ATTESA)
		throw new RuntimeException("Non si puo' modificare la playlist mentre in esecuzione.");
            ManagerContiene k = new ManagerContiene(y);
            y.getPlayList().inserisciPerManagerContiene(k);
            y.getBrano().inserisciPerManagerContiene(k);
        }
    }
    public static void elimina(TipoLinkContiene y) {
        if (y != null) {
	    if (y.getPlayList().getStato() != PlayList.Stato.ATTESA)
		throw new RuntimeException("Non si puo' modificare la playlist mentre in esecuzione.");
            ManagerContiene k = new ManagerContiene(y);
            y.getPlayList().eliminaPerManagerContiene(k);
            y.getBrano().eliminaPerManagerContiene(k);
        }
    }
}
