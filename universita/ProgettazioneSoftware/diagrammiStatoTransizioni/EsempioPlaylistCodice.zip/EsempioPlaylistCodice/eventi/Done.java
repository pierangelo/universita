package eventi;

import _gestioneeventi.*;

public class Done extends Evento {
    public Done(Listener m, Listener d) {
	super(m,d);
    }

    public boolean equals(Object o) {
        return super.equals(o);
    }
 
   public int hashCode() {
       return super.hashCode() + getClass().hashCode();  
    }
 
    public String toString() {
	return "Done(" + getMittente() + " -> " + getDestinatario() + ")";
    } 
}


