package eventi;

import _gestioneeventi.*;

public class Reset extends Evento {
    public Reset(Listener m, Listener d) {
	super(m,d);
    }

    public boolean equals(Object o) {
        return super.equals(o);
    }
 
   public int hashCode() {
       return super.hashCode() + getClass().hashCode();  
    }
 
    public String toString() {
	return "Reset(" + getMittente() + " -> " + getDestinatario() + ")";
    } 
}


