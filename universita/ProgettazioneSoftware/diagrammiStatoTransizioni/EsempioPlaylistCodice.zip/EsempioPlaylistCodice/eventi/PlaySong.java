package eventi;

import _gestioneeventi.*;
import brano.*;

public class PlaySong extends Evento {

    private Brano brano;

    public PlaySong(Listener m, Listener d, Brano b) {
	super(m,d);
	if (b == null) throw new RuntimeException("Formato messaggio irriconoscibile.");
	brano = b;
    }

    public Brano getBrano() { return brano; }

    public boolean equals(Object o) {
        if (super.equals(o)) {
            PlaySong e = (PlaySong) o;
            return brano == e.brano;
        }
        else return false;
    }
 
   public int hashCode() {
       return super.hashCode() + getClass().hashCode() + brano.hashCode();  
    }
 
    public String toString() {
	return "PlaySong(" + getMittente() + " -> " + getDestinatario() + " : " + brano + ")";
    } 
}


