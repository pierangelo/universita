package eventi;

import _gestioneeventi.*;
import player.*;

public class Play extends Evento {
    
    private Player player;
    
    public Play(Listener m, Listener d, Player p) {
	super(m,d);
	player = p;
    }

    public Player getPlayer() { return player; }

    public boolean equals(Object o) {
        if (super.equals(o)) {
	    Play p = (Play) o; 
	    return player == p.player;
	}
	return false;
    }
 
   public int hashCode() {
       return super.hashCode() + getClass().hashCode() + player.hashCode();  
    }
 
    public String toString() {
	return "Play(" + getMittente() + " -> " + getDestinatario() + " on " + player +")";
    } 
}


