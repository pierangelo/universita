package _gestioneeventi;


public interface Listener {
    public Evento fired(Evento e); // dato un evento esegue la transizione e eventualmente restituisce un nuovo evento
    //null se l'evento non c'e'
}