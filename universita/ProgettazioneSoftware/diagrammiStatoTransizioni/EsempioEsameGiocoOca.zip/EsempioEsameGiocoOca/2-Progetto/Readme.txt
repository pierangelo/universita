Mostriamo solo la responsabilita' delle classi.
