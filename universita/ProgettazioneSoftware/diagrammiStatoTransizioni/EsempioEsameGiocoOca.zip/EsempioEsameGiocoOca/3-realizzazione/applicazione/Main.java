package applicazione;

import attivita_composte.*;
import casella.*;
import casellaSalto.*;
import java.util.*;

public class Main {
	public static void main(String[] args) throws InterruptedException {

		// Creazione del tabellone di gioco

		Casella c1 = new Casella("1");
		Casella c2 = new Casella("2");
		CasellaSalto c3 = new CasellaSalto("Salto","3");
		Casella c4 = new Casella("4");
		Casella c5 = new Casella("5");
		Casella c6 = new Casella("6");
		Casella c7 = new Casella("7");
		Casella c8 = new Casella("8");
		CasellaSalto c9 = new CasellaSalto("Salto","9");
		Casella c10 = new Casella("10");

		c9.inserisciLinkSaltare(c5);
		c3.inserisciLinkSaltare(c8);

		c1.inserisciLinkSuccessore(c2);
		c2.inserisciLinkSuccessore(c3);
		c3.inserisciLinkSuccessore(c4);
		c4.inserisciLinkSuccessore(c5);
		c5.inserisciLinkSuccessore(c6);
		c6.inserisciLinkSuccessore(c7);
		c7.inserisciLinkSuccessore(c8);
		c8.inserisciLinkSuccessore(c9);
		c9.inserisciLinkSuccessore(c10);

		HashSet<Casella> tabellone = new HashSet<Casella>();
		tabellone.add(c1);
		tabellone.add(c2);
		tabellone.add(c3);
		tabellone.add(c4);
		tabellone.add(c5);
		tabellone.add(c6);
		tabellone.add(c7);
		tabellone.add(c8);
		tabellone.add(c9);
		tabellone.add(c10);

		Thread attivitaPrincipale = new Thread(
				new AttivitaPrincipale(tabellone));
		attivitaPrincipale.start();
	}
}
