package attivita_io;

import javax.swing.JOptionPane;

import _gestioneeventi.EsecuzioneEnvironment;

public class AttesaComando {
	public static void segnalefine() {
		JOptionPane.showMessageDialog(null,
				"Click su OK per fermare la partita", "Attendi segnale",
				JOptionPane.INFORMATION_MESSAGE);
		EsecuzioneEnvironment.disattivaListener();
	}
}
