package attivita_io;

import giocatore.*;
import java.util.*;

public class LeggiGiocatori {

	public static HashSet<Giocatore> perform() {

		HashSet<Giocatore> aux = new HashSet<Giocatore>();

		Giocatore g1 = new Giocatore("Massimo");
		Giocatore g2 = new Giocatore("Giuseppe");
		aux.add(g1);
		aux.add(g2);
		return aux;
	}
}
