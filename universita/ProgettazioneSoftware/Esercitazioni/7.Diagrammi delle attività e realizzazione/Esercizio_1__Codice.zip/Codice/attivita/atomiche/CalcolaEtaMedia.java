package attivita.atomiche;

import java.util.*;
import _framework.*;
import lega.EccezioneMolteplicita;
import lega.squadra.*;
import lega.giocatore.*;

public class CalcolaEtaMedia implements Task {
	// Task per il calcolo dell'eta' media dei giocatori di una squadra
	private final int ANNO_CORRENTE = 2010;
	private Squadra squadra;
	private boolean eseguita = false;
	private float risultato = 0;
	
	public CalcolaEtaMedia(Squadra squadra){
		if(squadra == null){
			throw (new RuntimeException("Il parametro non puo' essere null!"));
		}
		this.squadra = squadra;
	}
	
	public synchronized void esegui(Executor e){
		if (e == null || eseguita)
			return;
		eseguita = true;
		try{
			Set<Giocatore> giocatori = squadra.getLinkGioca();
			Iterator<Giocatore> it = giocatori.iterator();
			while(it.hasNext()){
				risultato += (ANNO_CORRENTE - it.next().getAnnoNascita());
			}
			risultato = risultato/giocatori.size();
		}
		catch (EccezioneMolteplicita ecc){
			ecc.printStackTrace();
		}
	}
	
	public synchronized boolean estEseguita(){
		return eseguita;
	}
	
	public synchronized float getRisultato(){
		if(!eseguita)
			throw new RuntimeException("Risultato non disponibile!");
		return risultato;
	}
}
