package attivita.complesse;

import lega.*;
import gui.*;

public class AttivitaPrincipale implements Runnable{
	boolean eseguita = false;
	
	public synchronized void run(){
		if (eseguita)
			return;
		eseguita = true;
		
		TipoLinkPartita partitaSelezionata = null;
		
		do{
			partitaSelezionata = AttivitaIO.LeggiPartita();
			
			if (partitaSelezionata != null){
				SottoramoSx sottoramoSx = new SottoramoSx(partitaSelezionata);
				SottoramoDx sottoramoDx = new SottoramoDx(partitaSelezionata);
				Thread t1 = new Thread(sottoramoSx);
				Thread t2 = new Thread(sottoramoDx);
				t1.start();
				t2.start();
				try{
					t1.join();
					t2.join();
				}
				catch (InterruptedException e){
					e.printStackTrace();
				}
				AttivitaIO.stampaHTML(sottoramoDx.getVinteCasa(),
						sottoramoDx.getVinteTrasferta(),
						sottoramoSx.getMediaEtaCasa(), 
						sottoramoSx.getMediaEtaTrasferta());
			}			
		}
		while(partitaSelezionata != null);
	}

	synchronized boolean estEseguita(){
		return eseguita;
	}

}
