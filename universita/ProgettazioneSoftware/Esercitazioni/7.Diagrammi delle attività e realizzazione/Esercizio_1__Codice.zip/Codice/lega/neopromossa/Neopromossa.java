package lega.neopromossa;

import java.util.*;

import lega.EccezioneMolteplicita;
import lega.giocatore.Giocatore;
import lega.squadra.Squadra;

public class Neopromossa extends Squadra {
	private final int MOLT_MIN_MAX = 15;
	
	public Neopromossa(String nome){
		super(nome);
	}
	
	public Set<Giocatore> getLinkGioca() throws EccezioneMolteplicita{
		Set<Giocatore> gioca = super.getLinkGioca();
		if(gioca.size() != MOLT_MIN_MAX){
			throw new EccezioneMolteplicita("Molteplicita' min/max violata!");
		}
		return gioca;
	}	
}
