package corridoriGUI;

public class Bang {
  private boolean sparato = false;

  public synchronized void spara() {
    sparato = true;
    notifyAll();
  }

  public synchronized void attendiBang() {
    // ATTENZIONE: se sparato = true, non devo eseguire la wait (la corsa e'
    // gia' iniziata)
    while (!sparato) {
      try {
        wait();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
}
