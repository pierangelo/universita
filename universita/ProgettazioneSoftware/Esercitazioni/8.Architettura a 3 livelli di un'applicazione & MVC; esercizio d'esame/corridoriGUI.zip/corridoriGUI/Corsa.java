package corridoriGUI;

import java.util.*;

public class Corsa {
  Vector<Corridore> classifica = new Vector<Corridore>();

  public synchronized Corridore getVincitore() {
    if (classifica.isEmpty())
      return null;
    return classifica.get(0);
  }

  public synchronized void setArrivato(Corridore corridore) {
    classifica.add(corridore);
    notifyAll(); // sblocca il Giudice in attesa del vincitore
  }

  public synchronized String toString() { // stampa classifica
    String result = "";
    for (int i = 0; i < classifica.size(); i++) {
      Corridore c = classifica.get(i);
      result += (i + 1) + ": " + c.getNome() + "\n";
    }
    return result;
  }
}
