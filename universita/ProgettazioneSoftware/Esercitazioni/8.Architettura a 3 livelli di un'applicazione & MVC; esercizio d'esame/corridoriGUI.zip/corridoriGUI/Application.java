package corridoriGUI;

import java.lang.Thread;

import javax.swing.JOptionPane;

public class Application {

  public static void main(String[] args) {
    boolean corretto = false;
    int numCorridori = 0;
    while (!corretto) {
      try {
        numCorridori = Integer.parseInt(JOptionPane
            .showInputDialog("Inserisci il numero di corridori"));
        if (numCorridori > 0)
          corretto = true;
        else
          JOptionPane.showMessageDialog(null,
              "Inserire un numero maggiore di 0!", "Errore!",
              JOptionPane.ERROR_MESSAGE);
      } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Inserire un numero intero!",
            "Errore!", JOptionPane.ERROR_MESSAGE);
      }
    }

    Thread[] threadCorridori = new Thread[numCorridori];
    Corsa corsa = new Corsa();

    // memorizza il numero di corridori pronti a partire
    ContatoreSincronizzato contatore = new ContatoreSincronizzato(numCorridori);
    Bang bang = new Bang();
    try {
      for (int i = 0; i < numCorridori; i++) {// fa partire tutti i corridori
        // crea un thread per ciascun corridore e lo avvia
        // i thread vengono memorizzati in un vettore per la sincronizzazione
        // futura
        threadCorridori[i] = new Thread(new Corridore("corridore " + i,
            contatore, bang, corsa));
        threadCorridori[i].start();
      }

      // Attende che tutti i corridori siano pronti (cioe' ciascuno e'
      // all'inizio della propria iterazione)
      contatore.attendiCompletamento();

      System.out.println("\n----- Corridori pronti a partire -----\n");

      Thread giudice = new Thread(new Giudice(corsa));
      giudice.start();

      Thread.sleep(10000);// Solo per dare il tempo di posizionare le finestre :-)

      // Notifica a tutti i corridori che possono partire
      System.out.println("\n----- BANG! -----\n");
      bang.spara();

      // main attende che il giudice abbia dichiarato il vincitore
      giudice.join();

      // main attende che tutti i corridori abbiano terminato la corsa
      for (int i = 0; i < numCorridori; i++) {
        threadCorridori[i].join();
      }

    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    System.out.println(corsa); // Stampa la classifica
  }
}
