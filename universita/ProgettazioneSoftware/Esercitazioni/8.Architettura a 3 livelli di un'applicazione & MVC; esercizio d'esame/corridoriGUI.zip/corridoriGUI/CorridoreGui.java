package corridoriGUI;

import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;

public class CorridoreGui extends JFrame {

  private JProgressBar barraAvanzamento;
  private JLabel numeroMetri;

  public CorridoreGui(String nome) {
    super(nome);
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    JLabel label = new JLabel("Metri percorsi: ");
    numeroMetri = new JLabel("0");
    barraAvanzamento = new JProgressBar(0, 100);
    getContentPane().setLayout(new FlowLayout());
    getContentPane().add(label);
    getContentPane().add(numeroMetri);
    getContentPane().add(barraAvanzamento);
    setSize(300, 100);
    setLocationByPlatform(true); // finestre posizionate "in cascata"
    setVisible(true);
  }

  public void aggiorna(final int metri) {
    // metriPercorsi = metri;
    Runnable target = new Runnable() {
      @Override
      public void run() {
        numeroMetri.setText(metri + "");
        barraAvanzamento.setValue(metri);
      }
    };
    SwingUtilities.invokeLater(target);
  }

  public void isVincitore() {
    Runnable target = new Runnable() {
      @Override
      public void run() {
        JLabel vincitore = new JLabel("HO VINTO!!!! :-)");
        getContentPane().add(vincitore);
        validate();
      }
    };
    SwingUtilities.invokeLater(target);
  }
}
