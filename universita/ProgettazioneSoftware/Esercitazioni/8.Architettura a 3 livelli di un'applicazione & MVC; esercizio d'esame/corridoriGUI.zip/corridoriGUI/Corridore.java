package corridoriGUI;

import javax.swing.SwingUtilities;

public class Corridore implements Runnable {

  private final String nome;
  private final static int METRI = 100;
  private ContatoreSincronizzato pronti;
  private final Bang bang;
  private final Corsa corsa;
  private CorridoreGui interfaccia;

  public Corridore(String nome, ContatoreSincronizzato pronti, Bang bang,
      Corsa unaCorsa) {
    this.nome = nome;
    this.bang = bang;
    this.pronti = pronti;
    this.corsa = unaCorsa;
  }

  public void run() {
    // creo GUI in EDT
    Runnable target = new Runnable() {
      @Override
      public void run() {
        interfaccia = new CorridoreGui(nome); 
      }
    };
    SwingUtilities.invokeLater(target);
    int spazio = 0;
    try {
      while (spazio < METRI) {
        if (spazio == 0) {// E' la prima iterazione
          System.out.println(nome + " pronto a partire");
          pronti.incrementa();
          bang.attendiBang();
        }
        spazio++;
        interfaccia.aggiorna(spazio);
        // Thread.sleep((int)(10.0*Math.random()+1)*100);
        Thread.sleep(100);
        // System.out.println(nome + " " + spazio + " metri");
      }
      System.out.println("Il corridore " + nome + " e' arrivato");
      corsa.setArrivato(this);
    } catch (InterruptedException err) {
      err.printStackTrace();
    }
  }

  public String getNome() {
    return nome;
  }

  public void setVincitore() {
    interfaccia.isVincitore();
  }
}
