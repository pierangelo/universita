package app.dominio;

import java.util.*;

public class Gara extends Observable {
  private final String nome;
  private final float distanza;
  private HashSet<Ciclista> vincitori;
  private HashSet<TipoLinkPartecipa> partecipa;
  public final int MINPARTECIPA = 2;

  public Gara(String nome, float distanza) {
    this.nome = nome;
    this.distanza = distanza;
    partecipa = new HashSet<TipoLinkPartecipa>();
    vincitori = new HashSet<Ciclista>();
  }

  public String getNome() {
    return nome;
  }

  public float getDistanza() {
    return distanza;
  }

  public void inserisciLinkPartecipa(TipoLinkPartecipa l) {
    if (l != null && l.getGara() == this) {
      ManagerPartecipa.inserisci(l);
    }
  }

  public synchronized void inserisciPerManagerPartecipa(ManagerPartecipa m) {
    if (m != null) {
      partecipa.add(m.getLink());
      setChanged();
      GaraUpdate aggiornamento = new GaraUpdate(m.getLink().getCiclista(), m.getLink().getKmPercorsi());
      notifyObservers(aggiornamento);
    }
  }

  public void eliminaLinkPartecipa(TipoLinkPartecipa l) {
    if (l != null && l.getGara() == this) {
      ManagerPartecipa.elimina(l);
    }
  }

  public void eliminaPerManagerPartecipa(ManagerPartecipa m) {
    if (m != null) {
      partecipa.remove(m.getLink());
    }
  }

  @SuppressWarnings("unchecked")
  public synchronized Set<TipoLinkPartecipa> getLinkPartecipa()
      throws EccezioneMoltMinMax {
    if (quantiCiclisti() < MINPARTECIPA)
      throw new EccezioneMoltMinMax("Eccezione Molteplicita' minima");
    return (HashSet<TipoLinkPartecipa>) partecipa.clone();
  }

  public int quantiCiclisti() {
    return partecipa.size();
  }

  public void inserisciLinkVincitore(Ciclista c) {
    /* DA COMPLETARE A CURA DELLO STUDENTE */
  }

  public void eliminaLinkVincitore(Ciclista c) {
    /* DA COMPLETARE A CURA DELLO STUDENTE */
  }

  @SuppressWarnings("unchecked")
  public Set<Ciclista> getLinkVincitori() throws EccezioneMoltMinMax,
      EccezioneSubset {
    /* DA COMPLETARE A CURA DELLO STUDENTE
     * Compreso controllo vincolo subset
     */
    return (HashSet<Ciclista>) vincitori.clone();
  }

  public int quantiVincitori() {
    return vincitori.size();
  }
}
