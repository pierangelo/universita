package app.attivita.atomiche;

import app._framework.*;
import app.dominio.*;

public class IscriviCiclista implements Task {
  private boolean eseguita = false;
  private Gara gara;
  private Ciclista ciclista;

  public IscriviCiclista(Gara gara, Ciclista ciclista) {
    this.gara = gara;
    this.ciclista = ciclista;
  }

  public synchronized void esegui(Executor e) {
    /* DA COMPLETARE A CURA DELLO STUDENTE */
  }

  public synchronized boolean estEseguita() {
    return eseguita;
  }
}
