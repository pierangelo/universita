package app.dominio;

public class ManagerPartecipa {
  private TipoLinkPartecipa link;

  private ManagerPartecipa(TipoLinkPartecipa link) {
    this.link = link;
  }

  public TipoLinkPartecipa getLink() {
    return link;
  }

  public static void inserisci(TipoLinkPartecipa l) {
    /* DA COMPLETARE A CURA DELLO STUDENTE */
  }

  public static void elimina(TipoLinkPartecipa l) {
    if (l != null) {
      ManagerPartecipa m = new ManagerPartecipa(l);
      l.getGara().eliminaPerManagerPartecipa(m);
      l.getCiclista().eliminaPerManagerPartecipa(m);
    }
  }

}
