package app.gui;

import javax.swing.*;

import app.dominio.*;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

public class GaraView extends JFrame implements Observer {

  private Container frmContentPane;
  protected Percorso percorso; // rendere accessibile all'attivita' di
                               // aggiornamento
  private Gara gara;

  public GaraView(Gara gara) {
    super(gara.getNome());
    this.gara = gara;
    // si registra come observer dell'oggetto di dominio che rappresenta la gara (model)
    gara.addObserver(this);
    Runnable target = new Runnable() {
      
      @Override
      public void run() {
        prepara();
      }
    };
    try {
      SwingUtilities.invokeAndWait(target);
    } catch (InterruptedException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (InvocationTargetException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  private void prepara() {// prepara la finestra per la
                                      // visualizzazione
    frmContentPane = getContentPane();
    percorso = new Percorso(gara);
    frmContentPane.add(percorso, BorderLayout.CENTER);
    JLabel infoGara = new JLabel("Gara: " + gara.getNome() + " - Km: " + gara.getDistanza());
    JPanel garaInfo = new JPanel();
    garaInfo.add(infoGara);
    frmContentPane.add(garaInfo, BorderLayout.PAGE_START);
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    pack();
    setLocationRelativeTo(null);
    setVisible(true);
  }
  
  @Override
  public void update(Observable gara, Object update) {
    //invocato in seguito ad un aggiornamento nella gara (vedi notifyObservers in Gara)
    GaraUpdate aggiornamento = (GaraUpdate)update;
    percorso.setPosizioneCiclista(aggiornamento.getCiclista(), aggiornamento.getKmPercorsi());
  }
}
