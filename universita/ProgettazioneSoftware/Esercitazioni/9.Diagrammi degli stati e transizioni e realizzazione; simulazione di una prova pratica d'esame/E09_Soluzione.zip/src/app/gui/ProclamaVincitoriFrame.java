package app.gui;

import java.awt.BorderLayout;
import java.util.Set;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import app.dominio.*;

public class ProclamaVincitoriFrame extends JFrame {
  private JList listaVincitori;
  private JTable tabellaCiclisti;
  private JTabbedPane tabPnl = new JTabbedPane();

  public ProclamaVincitoriFrame(final Set<Ciclista> vincitori,
      final Set<TipoLinkPartecipa> linkPartecipanti) {
    super("Riassunto della gara e vincitori");
    Runnable target = new Runnable() {
      
      @Override
      public void run() {
        listaVincitori = popolaListaVincitori(vincitori);
        tabellaCiclisti = popolaTabellaClassifica(linkPartecipanti);
        getContentPane().add(tabPnl, BorderLayout.CENTER);
        tabPnl.add("Tabella dei ciclisti", new JScrollPane(tabellaCiclisti));
        tabPnl.add("Lista dei vincitori", new JScrollPane(listaVincitori));
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
      }
    };
    SwingUtilities.invokeLater(target);
  }

  private JTable popolaTabellaClassifica(Set<TipoLinkPartecipa> linkPartecipanti) {
    String[][] tabella = new String[linkPartecipanti.size()][2];
    int riga = 0;
    for (TipoLinkPartecipa l : linkPartecipanti) {
      tabella[riga][0] = l.getCiclista().getNome();
      tabella[riga++][1] = l.getKmPercorsi() + "";
    }
    String[] intestazioni = { "Nome Ciclista", "Km percorsi" };
    return new JTable(tabella, intestazioni);
  }

  private JList popolaListaVincitori(Set<Ciclista> vincitori) {
    Vector<String> nomeVincitori = new Vector<String>();
    for (Ciclista vincitore : vincitori) {
      nomeVincitori.add(vincitore.getNome());
    }
    return new JList(nomeVincitori);
  }

}
