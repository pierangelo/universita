package app.gui;

import java.awt.event.*;

import app.attivita.complesse.*;

class ListenerFinestraPrincipale implements ActionListener {
  
  public void actionPerformed(ActionEvent evento) {
    Thread threadAttivitaPrincipale = new Thread(new AttivitaPrincipale());
    threadAttivitaPrincipale.start();
  }
}
