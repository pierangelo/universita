package app.gui;

import javax.swing.*;

import java.awt.*;

public class FinestraPrincipale extends JFrame {
  private final JLabel label = new JLabel("Premi per simulare una nuova gara");
  protected final JButton nuovaGara = new JButton("Nuova Gara");

  public FinestraPrincipale() {
    super("Simulazione gara");
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    nuovaGara.addActionListener(new ListenerFinestraPrincipale());
    Container frmContentPane = this.getContentPane();
    JPanel pannello = new JPanel();
    pannello.add(label);
    JPanel pannelloBottone = new JPanel();
    pannelloBottone.add(nuovaGara);
    frmContentPane.add(pannello, BorderLayout.PAGE_START);
    frmContentPane.add(pannelloBottone, BorderLayout.PAGE_END);
    pack();
    setLocationRelativeTo(null);
    setVisible(true);
  }

//  @Override
//  public Dimension getPreferredSize() {
//    return (new Dimension(200, 80));
//  }

  public void abilitaPulsanteNuovaGara() {
    nuovaGara.setEnabled(true);
  }

}
