package app.dominio;

public class GaraUpdate {
  
  private Ciclista ciclista;
  private float kmPercorsi;
  
  public GaraUpdate(Ciclista cic, float km) {
    ciclista = cic;
    kmPercorsi = km;
  }

  public Ciclista getCiclista() {
    return ciclista;
  }

  public float getKmPercorsi() {
    return kmPercorsi;
  }

}
