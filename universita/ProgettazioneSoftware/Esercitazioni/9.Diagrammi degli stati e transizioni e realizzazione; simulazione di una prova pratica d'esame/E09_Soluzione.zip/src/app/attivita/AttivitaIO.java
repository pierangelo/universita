package app.attivita;

import java.util.*;
import javax.swing.JOptionPane;

import app.dominio.*;
import app.gui.*;

public class AttivitaIO {
  
  private AttivitaIO() {}

  public static Gara inserisciDatiGara() {
    InserisciDatiGara frame = new InserisciDatiGara();  
    frame.aspettaOK();
    return new Gara(frame.leggiNome(), frame.leggiDistanza());
  }

  public static Ciclista inserisciDatiCiclista() {
    String nome;
    do {
      nome = JOptionPane.showInputDialog(null,
          "Specificare il nome del ciclista:", "Iscrizione Ciclista",
          JOptionPane.PLAIN_MESSAGE);
    } while (nome == null);

    return (new Ciclista(nome));
  }

  public static boolean chiediSeAltroCiclista() {
    int yn = JOptionPane.showConfirmDialog(null,
        "Si vuole iscrivere un altro ciclista alla gara",
        "Iscrizione Ciclista", JOptionPane.YES_NO_OPTION);
    return (yn == JOptionPane.YES_OPTION);
  }

  public static void proclamaVincitori(Gara gara) {
    Set<Ciclista> vincitori = null;
    Set<TipoLinkPartecipa> partecipanti = null;
    try {
      vincitori = gara.getLinkVincitori();
      partecipanti = gara.getLinkPartecipa();
      new ProclamaVincitoriFrame(vincitori, partecipanti);
    } catch (EccezioneMoltMinMax e) {
      e.printStackTrace();
      System.exit(1);
    } catch (EccezioneSubset e) {
      e.printStackTrace();
      System.exit(1);
    }

  }

  public static void visualizzaGara(Gara gara) {
    new GaraView(gara);
  }

}
