package app.attivita.complesse;

import app._framework.*;
import app._gestioneeventi.*;
import app.attivita.AttivitaIO;
import app.attivita.atomiche.*;
import app.dominio.*;

public class AttivitaPrincipale implements Runnable {
  private boolean eseguita = false;
  private Gara gara;
  private Ciclista ciclista;
  private boolean altro;
  private boolean inCorso;

  public synchronized void run() {
    if (eseguita == true)
      return;
    eseguita = true;

    gara = AttivitaIO.inserisciDatiGara();
    ciclista = AttivitaIO.inserisciDatiCiclista();
    Executor.perform(new IscriviCiclista(gara, ciclista));
    do {
      ciclista = AttivitaIO.inserisciDatiCiclista();
      Executor.perform(new IscriviCiclista(gara, ciclista));
      altro = AttivitaIO.chiediSeAltroCiclista();
    } while (altro);

    AttivitaIO.visualizzaGara(gara);

    Executor.perform(new AvviaGara(gara));
    do {
      try {
        Thread.sleep(100);
      } catch (InterruptedException eccezione) {
        eccezione.printStackTrace();
        System.exit(1);
      }
      TestFineGara testFineGara = new TestFineGara(gara);
      Executor.perform(testFineGara);
      inCorso = testFineGara.getRisultato();
    } while (inCorso);
    EsecuzioneEnvironment.disattivaListener();
    Executor.perform(new AggiornaVincitori(gara));
    AttivitaIO.proclamaVincitori(gara);
  }

  public synchronized boolean estEseguita() {
    return eseguita;
  }
}
