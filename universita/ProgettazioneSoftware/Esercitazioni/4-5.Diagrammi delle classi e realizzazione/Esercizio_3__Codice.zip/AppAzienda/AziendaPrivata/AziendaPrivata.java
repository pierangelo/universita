// File AppAzienda/AziendaPrivata/AziendaPrivata.java
package AppAzienda.AziendaPrivata;

import AppAzienda.Azienda.*;

public class AziendaPrivata extends Azienda {
  private float capitaleSociale;

  public AziendaPrivata(String nome, String descrizione, float capitaleSociale) {
    super(nome, descrizione);
    this.capitaleSociale = capitaleSociale;
  }

  public float getCapitaleSociale() {
    return capitaleSociale;
  }
  
  public void setCapitaleSociale(float capitaleSociale) {
    this.capitaleSociale = capitaleSociale;
  }
}
