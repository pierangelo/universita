// File AppAzienda/Azienda/Azienda.java
package AppAzienda.Azienda;

import AppAzienda.*;
import AppAzienda.Localita.*;
import java.util.*;

public abstract class Azienda {

  protected final String nome;
  protected final String descrizione;

  protected HashSet<Localita> sede;
  private final int MOLT_MIN_SEDE = 1;
  protected HashSet<TipoLinkControlla> controllata; // le aziende controllate da
                                                    // this
  protected TipoLinkControlla controllante; // l'azienda controllante (l'azienda
                                            // che controlla this)

  protected Azienda(String nome, String descrizione) {
    this.nome = nome;
    this.descrizione = descrizione;
    sede = new HashSet<Localita>();
    controllata = new HashSet<TipoLinkControlla>();
    controllante = null;
  }

  public String getNome() {
    return nome;
  }

  public String getDescrizione() {
    return descrizione;
  }

  public void inserisciLinkSede(Localita l) {
    if (l != null)
      sede.add(l);
  }

  public void eliminaLinkSede(Localita l) {
    if (l != null)
      sede.remove(l);
  }

  public Set<Localita> getLinkSede() throws EccezioneMolteplicita {
    if (sede.size() < MOLT_MIN_SEDE)
      throw new EccezioneMolteplicita("Molteplicita' minima violata");
    return (HashSet<Localita>) sede.clone();
  }

  public void inserisciLinkControllante(TipoLinkControlla c) {
    if (c != null && c.getControllata() == this) {
      ManagerControlla.inserisci(c);
    }
  }

  public void eliminaLinkControllante(TipoLinkControlla c) {
    if (c != null && c.getControllata() == this) {
      ManagerControlla.elimina(c);
    }
  }

  public TipoLinkControlla getLinkControllante() {
    return controllante;
  }

  public void inserisciLinkControllata(TipoLinkControlla c) {
    if (c != null && c.getControllante() == this) {
      ManagerControlla.inserisci(c);
    }
  }

  public void eliminaLinkControllata(TipoLinkControlla c) {
    if (c != null && c.getControllante() == this) {
      ManagerControlla.elimina(c);
    }
  }

  public Set<TipoLinkControlla> getLinkControllata() {
    return (HashSet<TipoLinkControlla>) controllata.clone();
  }

  public void inserisciControllantePerManagerControlla(ManagerControlla a) {
    if (a != null) {
      controllante = a.getLink();
    }
  }

  public void eliminaControllantePerManagerControlla(ManagerControlla a) {
    if (a != null) {
      controllante = null;
    }
  }

  public void inserisciControllataPerManagerControlla(ManagerControlla a) {
    if (a != null) {
      controllata.add(a.getLink());
    }
  }

  public void eliminaControllataPerManagerControlla(ManagerControlla a) {
    if (a != null) {
      controllata.remove(a.getLink());
    }
  }
}
