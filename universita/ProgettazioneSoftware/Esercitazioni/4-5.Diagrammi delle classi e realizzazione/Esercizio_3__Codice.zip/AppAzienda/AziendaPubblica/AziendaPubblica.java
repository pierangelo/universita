// File AppAzienda/AziendaPubblica/AziendaPubblica.java
package AppAzienda.AziendaPubblica;

import AppAzienda.*;
import AppAzienda.Azienda.*;
import AppAzienda.Ente.*;

public class AziendaPubblica extends Azienda {
  private Ente gestore;

  public AziendaPubblica(String nome, String descrizione) {
    super(nome, descrizione);
  }

  public void setGestore(Ente e) {
    if (e != null)
      gestore = e;
  }

  public Ente getGestore() throws EccezioneMolteplicita {
    if (gestore == null)
      throw new EccezioneMolteplicita("Molteplicita min/max violata");
    return gestore;
  }
}
