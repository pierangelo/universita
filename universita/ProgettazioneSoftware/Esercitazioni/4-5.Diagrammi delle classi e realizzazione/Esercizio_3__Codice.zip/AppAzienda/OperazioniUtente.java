// File AppAzienda/OperazioniUtente.java
package AppAzienda;

import AppAzienda.Azienda.*;
import AppAzienda.AziendaPrivata.*;
import java.util.*;

public final class OperazioniUtente {
  
  public static boolean controllaSeStessa(Azienda a) {
    Azienda azCorrente = a;
    while (azCorrente.getLinkControllante() != null) {
      Azienda controllante = azCorrente.getLinkControllante().getControllante();
      if (controllante == a)
        return true;
      azCorrente = controllante;
    }
    return false;
  }
  
  public static Set<AziendaPrivata> azPrivateControllateDa(Azienda a) {
    HashSet<AziendaPrivata> result = new HashSet<AziendaPrivata>();
    Set<TipoLinkControlla> linkControlla = a.getLinkControllata();
    Iterator<TipoLinkControlla> it = linkControlla.iterator();
    while (it.hasNext()) {
      TipoLinkControlla l = it.next();
      if (l.getControllata() instanceof AziendaPrivata)
        result.add((AziendaPrivata) l.getControllata());
    }
    return result;
  }
}
