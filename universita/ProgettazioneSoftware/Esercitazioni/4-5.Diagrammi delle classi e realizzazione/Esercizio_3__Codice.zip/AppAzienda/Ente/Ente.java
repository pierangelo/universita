// File AppAzienda/Ente/Ente.java
package AppAzienda.Ente;

public class Ente {
  private final String nome;
  private final String codice;

  public Ente(String nome, String codice) {
    this.nome = nome;
    this.codice = codice;
  }

  public String getNome() {
    return nome;
  }

  public String getCodice() {
    return codice;
  }
}
