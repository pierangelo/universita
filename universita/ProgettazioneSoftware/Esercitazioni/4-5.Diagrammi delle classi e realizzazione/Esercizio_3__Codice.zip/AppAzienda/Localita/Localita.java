// File AppAzienda/Localita/Localita.java
package AppAzienda.Localita;

public class Localita {
  private final String nome;
  private final String indirizzo;

  public Localita(String nome, String indirizzo) {
    this.nome = nome;
    this.indirizzo = indirizzo;
  }

  public String getNome() {
    return nome;
  }

  public String getIndirizzo() {
    return indirizzo;
  }
}
