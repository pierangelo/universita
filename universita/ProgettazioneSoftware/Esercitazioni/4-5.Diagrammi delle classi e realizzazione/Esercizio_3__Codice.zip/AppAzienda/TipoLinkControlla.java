// File AppAzienda/TipoLinkControlla.java
package AppAzienda;

import AppAzienda.Azienda.*;
import java.util.*;

public class TipoLinkControlla {
  private final Azienda controllante;
  private final Azienda controllata;

  public TipoLinkControlla(Azienda controllante, Azienda controllata)
      throws EccezionePrecondizioni {
    if (controllante == null || controllata == null) // CONTROLLO PRECONDIZIONI
      throw new EccezionePrecondizioni(
          "Gli oggetti devono essere inizializzati");
    this.controllante = controllante;
    this.controllata = controllata;
  }

  public boolean equals(Object o) {
    if (o != null && getClass().equals(o.getClass())) {
      TipoLinkControlla l = (TipoLinkControlla) o;
      return l.controllante == controllante && l.controllata == controllata;
    } else
      return false;
  }

  public int hashCode() {
    return controllante.hashCode() + controllata.hashCode();
  }

  public Azienda getControllante() {
    return controllante;
  }

  public Azienda getControllata() {
    return controllata;
  }

  public String toString() {
    return "<" + controllante + ", " + controllata + ">";
  }
}
