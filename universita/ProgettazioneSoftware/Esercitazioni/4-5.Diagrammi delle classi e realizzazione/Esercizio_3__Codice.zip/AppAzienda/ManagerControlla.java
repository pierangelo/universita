// File AppAzienda/ManagerControlla.java
package AppAzienda;

public final class ManagerControlla {
  private TipoLinkControlla link;

  private ManagerControlla(TipoLinkControlla link) {
    this.link = link;
  }

  public TipoLinkControlla getLink() {
    return link;
  }

  public static void inserisci(TipoLinkControlla y) {
    if (y != null && y.getControllata().getLinkControllante() == null) {
      ManagerControlla k = new ManagerControlla(y);
      y.getControllante().inserisciControllataPerManagerControlla(k);
      y.getControllata().inserisciControllantePerManagerControlla(k);
    }
  }
  
  public static void elimina(TipoLinkControlla y) {
    if (y != null && y.getControllata().getLinkControllante().equals(y)) {
      ManagerControlla k = new ManagerControlla(y);
      y.getControllante().eliminaControllataPerManagerControlla(k);
      y.getControllata().eliminaControllantePerManagerControlla(k);
    }
  }
}
