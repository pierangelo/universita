// File AppLibrerie/ManagerRichiede.java
package AppCostruzioni;

public final class ManagerRichiede {

  private TipoLinkRichiede link;

  private ManagerRichiede(TipoLinkRichiede link) {
    this.link = link;
  }

  public TipoLinkRichiede getLink() {
    return link;
  }

  public static void inserisci(TipoLinkRichiede y) {
    if (y != null) {
      ManagerRichiede k = new ManagerRichiede(y);
      k.link.getCostruzione().inserisciPerManagerRichiede(k);
      k.link.getTipoMattoncini().inserisciPerManagerRichiede(k);
    }
  }

  public static void elimina(TipoLinkRichiede y) {
    if (y != null) {
      ManagerRichiede k = new ManagerRichiede(y);
      y.getCostruzione().eliminaPerManagerRichiede(k);
      y.getTipoMattoncini().eliminaPerManagerRichiede(k);
    }
  }
}
