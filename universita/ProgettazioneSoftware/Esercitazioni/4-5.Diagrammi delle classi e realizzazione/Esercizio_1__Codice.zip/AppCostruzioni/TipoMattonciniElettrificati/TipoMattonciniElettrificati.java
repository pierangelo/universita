// File AppCostruzioni/TipoMattonciniElettrificati/TipoMattonciniElettrificati.java
package AppCostruzioni.TipoMattonciniElettrificati;

import AppCostruzioni.TipoMattoncini.*;

public final class TipoMattonciniElettrificati extends TipoMattoncini {
  private final String specificaElettrica;

  public TipoMattonciniElettrificati(String dimensioni, String colore,
      String specificaElettrica) {
    super(dimensioni, colore);
    this.specificaElettrica = specificaElettrica;
  }

  public String getSpecificaElettrica() {
    return specificaElettrica;
  }
}
