// File AppCostruzioni/EccezioneSubset.java
package AppCostruzioni;

public class EccezioneSubset extends Exception {
  private final String messaggio;

  public EccezioneSubset(String m) {
    messaggio = m;
  }

  public String toString() {
    return messaggio;
  }
}
