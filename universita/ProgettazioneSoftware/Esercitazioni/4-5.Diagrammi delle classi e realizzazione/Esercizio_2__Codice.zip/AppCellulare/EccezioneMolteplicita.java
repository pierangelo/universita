// File AppCellulare/EccezioneMolteplicita.java
package AppCellulare;

public class EccezioneMolteplicita extends Exception {
  private String messaggio;

  public EccezioneMolteplicita(String m) {
    messaggio = m;
  }

  public String toString() {
    return messaggio;
  }
}
