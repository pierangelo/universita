// File AppCellulare/TipoLinkOccupa.java
package AppCellulare;

import AppCellulare.IconaAttiva.*;
import AppCellulare.DisplayArea.*;
import java.util.*;

public class TipoLinkOccupa {
  private final IconaAttiva laIconaAttiva;
  private final DisplayArea laDisplayArea;
  private final boolean interamente;

  public TipoLinkOccupa(IconaAttiva a, DisplayArea da, boolean occupaInteramente)
      throws EccezionePrecondizioni {
    if (a == null || da == null) // CONTROLLO PRECONDIZIONI
      throw new EccezionePrecondizioni(
          "Gli oggetti devono essere inizializzati");
    laIconaAttiva = a;
    laDisplayArea = da;
    interamente = occupaInteramente;
  }

  public boolean equals(Object o) {
    if (o != null && getClass().equals(o.getClass())) {
      TipoLinkOccupa l = (TipoLinkOccupa) o;
      return l.laIconaAttiva == laIconaAttiva
          && l.laDisplayArea == laDisplayArea;
    } else
      return false;
  }

  public int hashCode() {
    return laIconaAttiva.hashCode() + laDisplayArea.hashCode();
  }

  public IconaAttiva getIconaAttiva() {
    return laIconaAttiva;
  }

  public DisplayArea getDisplayArea() {
    return laDisplayArea;
  }
  
  public boolean getInteramente() {
    return interamente;
  }

  public String toString() {
    return "<" + laIconaAttiva + ", " + laDisplayArea + ">";
  }
}
