// File AppCellulare/TipoLinkMostra.java
package AppCellulare;

import AppCellulare.IconaAttiva.*;
import AppCellulare.Animazione.*;

public class TipoLinkMostra {
  private final IconaAttiva laIconaAttiva;
  private final Animazione laAnimazione;

  public TipoLinkMostra(IconaAttiva ia, Animazione a)
      throws EccezionePrecondizioni {
    if (ia == null || a == null) // CONTROLLO PRECONDIZIONI
      throw new EccezionePrecondizioni(
          "Gli oggetti devono essere inizializzati");
    laIconaAttiva = ia;
    laAnimazione = a;
  }

  public boolean equals(Object o) {
    if (o != null && getClass().equals(o.getClass())) {
      TipoLinkMostra l = (TipoLinkMostra) o;
      return l.laIconaAttiva == laIconaAttiva && l.laAnimazione == laAnimazione;
    } else
      return false;
  }

  public int hashCode() {
    return laIconaAttiva.hashCode() + laAnimazione.hashCode();
  }

  public IconaAttiva getIconaAttiva() {
    return laIconaAttiva;
  }

  public Animazione getAnimazione() {
    return laAnimazione;
  }

  public String toString() {
    return "<" + laIconaAttiva + ", " + laAnimazione + ">";
  }
}
