// File AppCellulare/DisplayArea/DisplayArea.java
package AppCellulare.DisplayArea;

public class DisplayArea {
  private final int posizione;
  private final String backgrnd;

  public DisplayArea(int posizione, String backgrnd) {
    this.posizione = posizione;
    this.backgrnd = backgrnd;
  }

  public int getPosizione() {
    return posizione;
  }

  public String getBackgrnd() {
    return backgrnd;
  }
}
