// File AppCellulare/Icona/Icona.java
package AppCellulare.Icona;

public class Icona {
  protected final String codice;
  protected final String immagine;

  public Icona(String codice, String immagine) {
    this.codice = codice;
    this.immagine = immagine;
  }

  public String getCodice() {
    return codice;
  }

  public String getImmagine() {
    return immagine;
  }
}
