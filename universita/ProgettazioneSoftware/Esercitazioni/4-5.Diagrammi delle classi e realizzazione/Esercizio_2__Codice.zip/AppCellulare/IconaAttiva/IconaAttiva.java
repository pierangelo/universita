// File AppCellulare/IconaAttiva/IconaAttiva.java
package AppCellulare.IconaAttiva;

import AppCellulare.*;
import AppCellulare.Icona.*;
import AppCellulare.Applicazione.*;

import java.util.*;

public final class IconaAttiva extends Icona {
  
  private final int MOLT_MIN_MOSTRA = 1, MOLT_MIN_OCCUPA = 1;
  private final String suonoAlClick;
  private Applicazione applicazione;
  private LinkedList<TipoLinkMostra> mostra; //ordered
  private HashSet<TipoLinkOccupa> occupa;

  public IconaAttiva(String codice, String immagine, String suonoAlClick) {
    super(codice, immagine);
    this.suonoAlClick = suonoAlClick;
    applicazione = null;
    mostra = new LinkedList<TipoLinkMostra>();
    occupa = new HashSet<TipoLinkOccupa>();
  }

  public String getSuonoAlClick() {
    return suonoAlClick;
  }

  public void inserisciApplicazione(Applicazione a) {
    if (a != null)
      this.applicazione = a;
  }

  public Applicazione getApplicazione() throws EccezioneMolteplicita {
    if (applicazione == null)
      throw new EccezioneMolteplicita("Molteplicita' min/max violate");
    return applicazione;
  }

  public void eliminaApplicazione() {
    applicazione = null;
  }
  
  public void inserisciLinkMostra(TipoLinkMostra a) {
    if (a != null && a.getIconaAttiva() == this)
      ManagerMostra.inserisci(a);
  }

  public void eliminaLinkMostra(TipoLinkMostra a) {
    if (a != null && a.getIconaAttiva() == this)
      ManagerMostra.elimina(a);
  }

  public void inserisciPerManagerMostra(ManagerMostra a) {
    if (a != null && !mostra.contains(a.getLink())) {
      mostra.add(a.getLink());
    }
  }

  public void eliminaPerManagerMostra(ManagerMostra a) {
    if (a != null)
      mostra.remove(a.getLink());
  }

  public List<TipoLinkMostra> getLinkMostra() throws EccezioneMolteplicita {
    if (mostra.size() < MOLT_MIN_MOSTRA)
      throw new EccezioneMolteplicita("Molteplicita' minima violata");
    return (LinkedList<TipoLinkMostra>) mostra.clone();
  }

  public void inserisciLinkOccupa(TipoLinkOccupa a) {
    if (a != null && a.getIconaAttiva() == this)
      occupa.add(a);
  }

  public void EliminaLinkOccupa(TipoLinkOccupa a) {
    if (a != null && a.getIconaAttiva() == this)
      occupa.remove(a);
  }

  public Set<TipoLinkOccupa> getLinkOccupa() throws EccezioneMolteplicita {
    if (occupa.size() < MOLT_MIN_OCCUPA)
      throw new EccezioneMolteplicita("Molteplicita' minima violata");
    return (HashSet<TipoLinkOccupa>) occupa.clone();
  }

}
