// File AppCellulare/ManagerMostra.java
package AppCellulare;

public final class ManagerMostra {
  
  private TipoLinkMostra link;

  private ManagerMostra(TipoLinkMostra link) {
    this.link = link;
  }

  public TipoLinkMostra getLink() {
    return link;
  }

  public static void inserisci(TipoLinkMostra y) {
    if (y != null) {
      ManagerMostra k = new ManagerMostra(y);
      y.getIconaAttiva().inserisciPerManagerMostra(k);
      y.getAnimazione().inserisciPerManagerMostra(k);
    }
  }

  public static void elimina(TipoLinkMostra y) {
    if (y != null) {
      ManagerMostra k = new ManagerMostra(y);
      y.getIconaAttiva().eliminaPerManagerMostra(k);
      y.getAnimazione().eliminaPerManagerMostra(k);
    }
  }
}
