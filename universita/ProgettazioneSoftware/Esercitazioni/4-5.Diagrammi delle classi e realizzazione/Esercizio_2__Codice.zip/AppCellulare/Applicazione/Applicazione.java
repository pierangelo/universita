// File AppCellulare/Applicazione/Applicazione.java
package AppCellulare.Applicazione;

public class Applicazione {
  private final String nome;
  private final String nomeFile;

  public Applicazione(String nome, String nomeFile) {
    this.nome = nome;
    this.nomeFile = nomeFile;
  }

  public String getNome() {
    return nome;
  }

  public String getNomeFile() {
    return nomeFile;
  }
}
