// File AppCellulare/OperazioniUtente.java
package AppCellulare;

import AppCellulare.IconaAttiva.*;
import AppCellulare.Animazione.*;
import java.util.*;

public final class OperazioniUtente {
  
  public static List<Animazione> invertiAnimazioni(IconaAttiva ia)
      throws EccezioneMolteplicita {
    HashSet<TipoLinkMostra> linkAnimazioni = new HashSet<TipoLinkMostra>();
    List<TipoLinkMostra> linkMostra = ia.getLinkMostra();
    Iterator<TipoLinkMostra> it = linkMostra.iterator();
    while (it.hasNext()) {
      TipoLinkMostra l = it.next();
      linkAnimazioni.add(l);
    }
    LinkedList<Animazione> result = new LinkedList<Animazione>();
    int i = linkAnimazioni.size();
    while (i > 0) {
      Iterator<TipoLinkMostra> itA = linkAnimazioni.iterator();
      while (itA.hasNext()) {
        TipoLinkMostra la = itA.next();
        if (linkMostra.indexOf(la) == i) {
          linkAnimazioni.remove(la);
          result.add(la.getAnimazione());
          i--;
          // NOTA: il ciclo continua anche se l'elemento corrente e'
          // stato scelto. Il prossimo elemento da selezionare
          // potrebbe, infatti, trovarsi in quelli non ancora scansionati.
        }
      }// while(itA.hasNext())
    }// while(i > 0)
    return result;
  }

  public static Set<IconaAttiva> chiMostra(Animazione a) {
    HashSet<IconaAttiva> result = new HashSet<IconaAttiva>();
    Set<TipoLinkMostra> linksMostra = a.getLinkMostra();
    Iterator<TipoLinkMostra> it = linksMostra.iterator();
    while (it.hasNext()) {
      TipoLinkMostra linkMostra = it.next();
      result.add(linkMostra.getIconaAttiva());
    }
    return result;
  }
}
