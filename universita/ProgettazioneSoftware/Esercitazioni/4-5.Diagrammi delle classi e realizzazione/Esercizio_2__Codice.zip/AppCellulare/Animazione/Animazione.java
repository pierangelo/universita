// File AppCellulare/Animazione/Animazione.java
package AppCellulare.Animazione;

import AppCellulare.*;
import AppCellulare.DisplayArea.DisplayArea;

import java.util.*;

public class Animazione {
  private final String linkProg;
  private HashSet<TipoLinkMostra> mostra;
  private HashSet<DisplayArea> linkCoinvolge;
  private final int MOLT_MIN_COINVOLGE = 1;

  public Animazione(String linkProg) {
    this.linkProg = linkProg;
    mostra = new HashSet<TipoLinkMostra>();
    linkCoinvolge = new HashSet<DisplayArea>();
  }

  public String getLinkProg() {
    return linkProg;
  }
  
  public void inserisciLinkMostra(TipoLinkMostra a) {
    if (a != null && a.getAnimazione() == this)
      ManagerMostra.inserisci(a);
  }

  public void eliminaLinkMostra(TipoLinkMostra a) {
    if (a != null && a.getAnimazione() == this)
      ManagerMostra.elimina(a);
  }
  
  public void inserisciPerManagerMostra(ManagerMostra a) {
    if (a != null)
      mostra.add(a.getLink());
  }

  public void eliminaPerManagerMostra(ManagerMostra a) {
    if (a != null)
      mostra.remove(a.getLink());
  }

  public Set<TipoLinkMostra> getLinkMostra() {
    return (HashSet<TipoLinkMostra>) mostra.clone();
  }

  public void inserisciLinkCoinvolge(DisplayArea da) {
    if (da != null)
      linkCoinvolge.add(da);
  }
  
  public void eliminaLinkCoinvolge(DisplayArea da) {
    if (da != null)
      linkCoinvolge.remove(da);
  }

  public Set<DisplayArea> getLinkCoinvolge() throws EccezioneMolteplicita {
    if (linkCoinvolge.size() < MOLT_MIN_COINVOLGE)
      throw new EccezioneMolteplicita("Cardinalita' minima violata");
    return (HashSet<DisplayArea>) linkCoinvolge.clone();
  }
}
