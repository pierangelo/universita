package app.applicazione;

import javax.swing.SwingUtilities;

import app.dominio.*;
import app.gui.*;

public class Main {
  
  private Main() {}
  
  public static void main(String args[]) {
    inserisciSouvenir();
    Runnable target = new Runnable() {
      
      @Override
      public void run() {
        new FinestraPrincipale();       
      }
    };
    SwingUtilities.invokeLater(target);
  }

  private static void inserisciSouvenir() {
    // Inserisce l'insieme dei souvenir in vendita
    try {
      Articoli.aggiungiSouvenir(new Berretto("Londra", (float) 3.50, "blu", 6));
      Articoli
          .aggiungiSouvenir(new Berretto("Roma", (float) 4.50, "giallo", 7));
      Articoli.aggiungiSouvenir(new Berretto("Melbourne", (float) 3.50,
          "verde", 4));
      Articoli.aggiungiSouvenir(new Berretto("San Diego", (float) 2.50,
          "rosso", 9));

      Articoli.aggiungiSouvenir(new Magnete("Roma", (float) 2.5, 4, 2));
      Articoli.aggiungiSouvenir(new Magnete("Eindhoven", (float) 4.5, 7, 9));
      Articoli.aggiungiSouvenir(new Magnete("Toronto", (float) 1.5, 2, 2));
      Articoli.aggiungiSouvenir(new Magnete("New York", (float) 9.5, 8, 8));
    } catch (EccezionePrecondizioni ecc) {
      ecc.printStackTrace();
      System.exit(1);
    }
  }

}
