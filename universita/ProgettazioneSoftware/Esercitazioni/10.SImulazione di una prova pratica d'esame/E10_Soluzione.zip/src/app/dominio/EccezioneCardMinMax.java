package app.dominio;

public class EccezioneCardMinMax extends Exception {
  private String messaggio;

  public EccezioneCardMinMax(String m) {
    messaggio = m;
  }

  public String toString() {
    return messaggio;
  }
}
