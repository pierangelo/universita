package app.dominio;

public class ManagerComprende {
  
  private TipoLinkComprende link;
  
  private ManagerComprende(TipoLinkComprende x) {
    link = x;
  }

  public TipoLinkComprende getLink() {
    return link;
  }

  public static void inserisci(TipoLinkComprende y) {
    if (y != null) {
      ManagerComprende k = new ManagerComprende(y);
      y.getSouvenir().inserisciLinkPerManagerComprende(k);
      y.getScontrino().inserisciLinkPerManagerComprende(k);
    }
  }

  public static void elimina(TipoLinkComprende y) {
    if (y != null) {
      ManagerComprende k = new ManagerComprende(y);
      y.getSouvenir().eliminaLinkPerManagerComprende(k);
      y.getScontrino().eliminaLinkPerManagerComprende(k);
    }
  }

}
