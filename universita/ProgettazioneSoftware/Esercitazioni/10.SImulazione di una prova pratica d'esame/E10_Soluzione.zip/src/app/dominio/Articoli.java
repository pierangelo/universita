package app.dominio;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;

public class Articoli {
  
  private static HashMap<String, Souvenir> listaSouvenir = new HashMap<String, Souvenir>();

  public static boolean aggiungiSouvenir(Souvenir s) {
    if (!listaSouvenir.containsKey(s.toString())) {
      listaSouvenir.put(s.toString(), s);
      return (true);
    }
    else
      return (false);
  }

  public static Souvenir getSouvenirDaDescrizione(String descrizione) {
    // Restituisce il souvenir a partire dalla sua descrizione (non esistono
    // descrizioni duplicate)
    return listaSouvenir.get(descrizione);
  }

  public static Collection<Souvenir> getListaSouvenir() {
    return (Collections.unmodifiableCollection(listaSouvenir.values()));
  }

}
