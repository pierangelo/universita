package app.attivita.atomiche;

import app._framework.*;
import app.dominio.*;

public class CreaNuovoScontrino implements Task {
  
  private Scontrino scontrino = null;
  private boolean eseguita = false;

  public synchronized void esegui(Executor e) {
    if (e == null || eseguita)
      return;
    eseguita = true;
    scontrino = new Scontrino();
  }

  public synchronized boolean estEseguita() {
    return eseguita;
  }

  public synchronized Scontrino getRisultato() {
    if (!eseguita)
      throw new RuntimeException("Risultato non pronto!");
    return scontrino;
  }
}
