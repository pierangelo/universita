package app.attivita.atomiche;

import app._framework.*;
import app.dominio.*;
import app.gui.*;

import java.util.*;

public class LeggiMagneti implements Task {
  private boolean eseguita = false;
  private HashSet<String> listaMagneti = new HashSet<String>();

  public synchronized void esegui(Executor e) {
    if (eseguita || e == null)
      return;
    eseguita = true;
    
    Collection<Souvenir> listaSouvenir = Articoli.getListaSouvenir();
    Iterator<Souvenir> listaSouvenirIt = listaSouvenir.iterator();
    while (listaSouvenirIt.hasNext()) {
      Souvenir souvenirCorrente = listaSouvenirIt.next();
      if (souvenirCorrente.getClass() == Magnete.class) {
        listaMagneti.add(souvenirCorrente.toString());
      }
    }
  }

  public synchronized boolean estEseguita() {
    return eseguita;
  }

  @SuppressWarnings("unchecked")
  public Set<String> getRisultato() {
    if (!eseguita)
      throw new RuntimeException("Risultato non pronto!");
    return (HashSet<String>) listaMagneti.clone();
  }
}
