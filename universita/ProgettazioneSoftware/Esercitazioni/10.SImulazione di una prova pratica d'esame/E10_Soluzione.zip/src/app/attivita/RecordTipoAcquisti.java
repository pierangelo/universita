package app.attivita;

public class RecordTipoAcquisti {
  private final boolean magneti;
  private final boolean berretti;

  public RecordTipoAcquisti(boolean magneti, boolean berretti) {
    this.magneti = magneti;
    this.berretti = berretti;
  }

  public boolean isMagneti() {
    return magneti;
  }

  public boolean isBerretti() {
    return berretti;
  }
}
