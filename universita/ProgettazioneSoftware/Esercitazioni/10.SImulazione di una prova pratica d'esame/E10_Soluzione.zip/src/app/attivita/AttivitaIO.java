package app.attivita;

import java.lang.reflect.InvocationTargetException;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import app.gui.SelezionaSouvenir;
import app.gui.VisioneScontrino;

public class AttivitaIO {
  
  private static final String titolo = "Distributore souvenir";

  public static RecordTipoAcquisti chiediTipoSouvenir() {
    boolean berretti = false;
    boolean magneti = false;
    String[] scelte = { "Magneti", "Berretti", "Magneti e Berretti" };
    String scelta = (String) JOptionPane.showInputDialog(null,
        "Che cosa si desidera comprare?", titolo, JOptionPane.QUESTION_MESSAGE,
        null, scelte, scelte[0]);
    if (scelta != null) {
      berretti = scelta.contains("Berretti");
      magneti = scelta.contains("Magneti");
    }
    return (new RecordTipoAcquisti(magneti, berretti));
  }

  public static RecordAcquisto mostraSouvenirPerSelezione(Set<String> insiemeSouvenir) {
    Target target = new Target(insiemeSouvenir);
    try {
      SwingUtilities.invokeAndWait(target);
    } catch (InterruptedException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (InvocationTargetException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    SelezionaSouvenir finestra = target.getSelezionaSouvenir();
    finestra.aspettaOK();
    RecordAcquisto record = new RecordAcquisto(finestra.leggiDescrizione(), finestra.leggiQuantita());
    return record;
  }

  public static boolean altroMagnete() {
    int yn = JOptionPane.showConfirmDialog(null,
        "Si desidera comprare altri magneri?", titolo,
        JOptionPane.YES_NO_OPTION);
    return (yn == JOptionPane.YES_OPTION);
  }

  public static boolean altroBerretto() {
    int yn = JOptionPane.showConfirmDialog(null,
        "Si desidera comprare altri berretti?", titolo,
        JOptionPane.YES_NO_OPTION);
    return (yn == JOptionPane.YES_OPTION);
  }

  public static void mostraScontrino(final RecordScontrino record) {
    Runnable target = new Runnable() {
      
      @Override
      public void run() {
        new VisioneScontrino(record);
      }
    };
    SwingUtilities.invokeLater(target);
//    VisioneScontrino frame = new VisioneScontrino(record);
//    synchronized (frame) {
//      try {
//        frame.wait();
//      } catch (InterruptedException e) {
//        e.printStackTrace();
//      }
//    }
  }
  
  private static class Target implements Runnable {
    
    private Set<String> insieme;
    private SelezionaSouvenir selSouvenir;
    
    public Target(Set<String> insiemeSouvenir) {
      insieme = insiemeSouvenir;
    }
    
    @Override
    public void run() {
      selSouvenir = new SelezionaSouvenir(insieme);
    }
    
    public SelezionaSouvenir getSelezionaSouvenir() {
      return selSouvenir;
    }
  }

}