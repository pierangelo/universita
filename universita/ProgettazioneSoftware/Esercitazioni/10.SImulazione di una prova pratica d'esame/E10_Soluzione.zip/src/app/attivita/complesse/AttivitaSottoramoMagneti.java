package app.attivita.complesse;

import java.util.*;
import app._framework.*;
import app.attivita.*;
import app.attivita.atomiche.*;
import app.dominio.*;

public class AttivitaSottoramoMagneti implements Runnable {
  
  private boolean eseguita = false;
  private Scontrino scontrinoCorrente = null;
  private boolean ancoraMagneti = true;
  private Set<String> magnetiLetti;
  private RecordAcquisto magneteSelezionato;

  public AttivitaSottoramoMagneti(Scontrino scontrinoCorrente) {
    this.scontrinoCorrente = scontrinoCorrente;
  }

  public synchronized void run() {
    if (eseguita)
      return;
    eseguita = true;

    while (ancoraMagneti) {
      LeggiMagneti leggiMagneti = new LeggiMagneti();
      Executor.perform(leggiMagneti);
      magnetiLetti = leggiMagneti.getRisultato();

      magneteSelezionato = AttivitaIO.mostraSouvenirPerSelezione(magnetiLetti);

      AggiornaScontrino aggiornaScontrino = new AggiornaScontrino(magneteSelezionato, scontrinoCorrente);
      Executor.perform(aggiornaScontrino);

      ancoraMagneti = AttivitaIO.altroMagnete();
    }
  }
}
