package app.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SelezionaSouvenirListener implements ActionListener {
  private SelezionaSouvenir frame;

  public SelezionaSouvenirListener(SelezionaSouvenir frame) {
    this.frame = frame;
    frame.dispose();
  }

  public void actionPerformed(ActionEvent arg0) {
    frame.descrizione = (String)frame.souvenirCbx.getSelectedItem();
    try {
      frame.quantita = Integer.parseInt(frame.quantitaTxt.getText());
      if(frame.quantita > 0) {
        synchronized (frame.getContentPane()) {
          frame.setSelezionato();
          frame.getContentPane().notify();
          frame.dispose();
        }
      }
      else
        ErrorNotifier.notifyError("Inserire i dati correttamente!");
    }
    catch (Exception e) {
      ErrorNotifier.notifyError("Inserire i dati correttamente!");
    }
  }

}
