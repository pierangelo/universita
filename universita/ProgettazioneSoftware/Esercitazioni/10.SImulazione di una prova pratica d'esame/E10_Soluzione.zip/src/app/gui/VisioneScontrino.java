package app.gui;

import java.awt.BorderLayout;
import java.util.*;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import app.attivita.RecordAcquisto;
import app.attivita.RecordScontrino;

public class VisioneScontrino extends JFrame {
 
  private JPanel okPnl = new JPanel();
  private JButton okBtn = new JButton("OK");
  private JPanel centroPnl = new JPanel();
  
  public VisioneScontrino(RecordScontrino record) {
    super("Scontrino");
    
    JPanel datiScontrino = new JPanel();
    datiScontrino.setLayout(new BoxLayout(datiScontrino, BoxLayout.Y_AXIS));
    datiScontrino.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    
    JLabel numScontrino = new JLabel("Numero scontrino: " + record.getNumero());
    numScontrino.setAlignmentX(CENTER_ALIGNMENT);
    JLabel dataScontrino = new JLabel("Data: " + record.getEmissione());
    dataScontrino.setAlignmentX(CENTER_ALIGNMENT);
    
    datiScontrino.add(numScontrino);
    datiScontrino.add(dataScontrino);
    
    JLabel totaleLbl = new JLabel("Totale Spesa: " + record.getTotale());
    
    
    String[][] tab = creaTabella(record.getInsiemeRecord());
    MyTableModel modello = new MyTableModel(tab);
    JTable tabella = new JTable(modello);
    centroPnl.add(new JScrollPane(tabella));
    
    okPnl.add(totaleLbl);
    okPnl.add(okBtn);
    okBtn.addActionListener(new VisioneScontrinoListener(this));
    
    getContentPane().add(datiScontrino, BorderLayout.PAGE_START);
    getContentPane().add(centroPnl, BorderLayout.CENTER);
    getContentPane().add(okPnl, BorderLayout.PAGE_END);
    
    pack();
    setLocationRelativeTo(null);// finestre posizionate "in cascata"
    setVisible(true);
  }

  private String[][] creaTabella(Set<RecordAcquisto> insieme) {
    Iterator<RecordAcquisto> iter = insieme.iterator();
    String[][] retValue = new String[insieme.size()][2];
    int i = 0;
    while (iter.hasNext()) {
      RecordAcquisto elem = iter.next();
      retValue[i][0] = elem.getDescrizione();
      retValue[i][1] = elem.getQuantita() + "";
      i++;
    }
    return (retValue);
  }
  
  class MyTableModel extends AbstractTableModel {
    
    private String[] columnNames = {"Souvenir", "Quantita'"};
    private Object[][] data;

    public MyTableModel(String[][] data) {
      this.data = data;
    }
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return data.length;
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
        return data[row][col];
    }

    public Class getColumnClass(int c) {
        return getValueAt(0, c).getClass();
    }

    public boolean isCellEditable(int row, int col) {
       return false;
    }
  }
}
