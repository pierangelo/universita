package app.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VisioneScontrinoListener implements ActionListener {

  private VisioneScontrino frame;

  public VisioneScontrinoListener(VisioneScontrino frame) {
    this.frame = frame;
  }

  public void actionPerformed(ActionEvent arg0) {
    frame.dispose();
  }

}
