package app.gui;

import java.awt.event.*;
import app.attivita.complesse.AttivitaPrincipale;

public class FinestraPrincipaleListener implements ActionListener {

  public void actionPerformed(ActionEvent arg0) {
    nuovoAcquisto();
  }

  private void nuovoAcquisto() {
    AttivitaPrincipale attivitaPrincipale = new AttivitaPrincipale();
    Thread t = new Thread(attivitaPrincipale);
    t.start();
  }

}
