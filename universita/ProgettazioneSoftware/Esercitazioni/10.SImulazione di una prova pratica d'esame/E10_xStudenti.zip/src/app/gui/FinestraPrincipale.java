package app.gui;

import java.awt.BorderLayout;

import javax.swing.*;

public class FinestraPrincipale extends JFrame {

  public FinestraPrincipale() {
    super("Menu Principale");
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    JPanel pannello = new JPanel();
    pannello.add(new JLabel("Premi per iniziare una nuova sessione di acquisto"));
    JPanel pannelloBottone = new JPanel();
    JButton bottone = new JButton("Acquista");
    pannelloBottone.add(bottone);
    bottone.addActionListener(new FinestraPrincipaleListener());
    getContentPane().add(pannello, BorderLayout.PAGE_START);
    getContentPane().add(pannelloBottone, BorderLayout.PAGE_END);
    pack();
    setLocationRelativeTo(null);
    setVisible(true);
  }
}
