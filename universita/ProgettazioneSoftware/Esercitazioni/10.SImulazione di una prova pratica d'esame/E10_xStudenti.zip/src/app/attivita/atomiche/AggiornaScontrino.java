package app.attivita.atomiche;

import java.util.*;
import app._framework.*;
import app.attivita.RecordAcquisto;
import app.dominio.*;

public class AggiornaScontrino implements Task {
  
  private boolean eseguita = false;
  private Scontrino scontrinoCorrente;
  private RecordAcquisto recordAcquisto;

  public AggiornaScontrino(RecordAcquisto recordAcquisto, Scontrino scontrino) {
    this.scontrinoCorrente = scontrino;
    this.recordAcquisto = recordAcquisto;
  }

  public synchronized void esegui(Executor e) {
    if (eseguita || e == null)
      return;
    eseguita = true;
    // A partire dalla descrizione dell'acquisto ottiene un riferimento al
    // Souvenir acquistato
    // (Non possono esistere duplicati delle descrizioni)
    Souvenir souvenirAcquistato = Articoli.getSouvenirDaDescrizione(recordAcquisto.getDescrizione());
    try {
      TipoLinkComprende nuovoLink = new TipoLinkComprende(souvenirAcquistato,
          scontrinoCorrente, recordAcquisto.getQuantita());

      // Se e' gia' presente un link comprende tra scontrinoCorrente e
      // souvenirAcquistato, deve essere rimpiazzato da un link analogo
      // con quantita' pari a quella del link presente pi� la quantita' del
      // souvenir acquistata

      if (scontrinoCorrente.getLinkComprende().contains(nuovoLink)) {
        /* DA COMPLETARE A CURA DELLO STUDENTE */
        
      }
      else {
        // Altrimenti inserisce il nuovo link
        /* DA COMPLETARE A CURA DELLO STUDENTE */
        
      }
    }
    catch (EccezionePrecondizioni ecc) {
      ecc.printStackTrace();
      System.exit(1);
    }
  }
}
