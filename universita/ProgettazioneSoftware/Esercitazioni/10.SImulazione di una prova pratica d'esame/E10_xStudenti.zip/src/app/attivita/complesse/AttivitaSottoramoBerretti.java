package app.attivita.complesse;

import java.util.*;

import app._framework.*;
import app.attivita.*;
import app.attivita.atomiche.*;
import app.dominio.*;

public class AttivitaSottoramoBerretti implements Runnable {
  
  private boolean eseguita = false;
  private Scontrino scontrinoCorrente = null;
  private boolean ancoraBerretti = true;
  private Set<String> berrettiLetti;
  private RecordAcquisto berrettoSelezionato;

  public AttivitaSottoramoBerretti(Scontrino scontrinoCorrente) {
    this.scontrinoCorrente = scontrinoCorrente;
  }

  public synchronized void run() {
    if (eseguita)
      return;
    eseguita = true;

    while (ancoraBerretti) {
      /* DA COMPLETARE A CURA DELLO STUDENTE */
      
    }
  }
}
