package app.attivita;

import app.dominio.*;

public class RecordAcquisto {
  private final String descrizione;
  private final int quantita;

  public RecordAcquisto(String descrizione, int quantita) {
    this.descrizione = descrizione;
    this.quantita = quantita;
  }

  public String getDescrizione() {
    return descrizione;
  }

  public int getQuantita() {
    return quantita;
  }

}
