package app.dominio;

public class TipoLinkComprende {
  private final Souvenir souvenir;
  private final Scontrino scontrino;
  private final int quantita;

  public TipoLinkComprende(Souvenir souvenir, Scontrino scontrino, int quantita)
      throws EccezionePrecondizioni {
    if (souvenir == null || scontrino == null)
      throw (new EccezionePrecondizioni("Impossibile passare dei valori nulli"));
    if (quantita <= 0)
      throw (new EccezionePrecondizioni(
          "La quantita' deve essere un valore positivo"));
    this.souvenir = souvenir;
    this.scontrino = scontrino;
    this.quantita = quantita;
  }

  public Souvenir getSouvenir() {
    return souvenir;
  }

  public Scontrino getScontrino() {
    return scontrino;
  }

  public int hashCode() {
    return souvenir.hashCode() + scontrino.hashCode();
  }

  public int getQuantita() {
    return quantita;
  }

  @Override
  public boolean equals(Object obj) {
    /* DA COMPLETARE A CURA DELLO STUDENTE */
    
    return true;
  }

}
