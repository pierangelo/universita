package app.dominio;

import java.util.*;

public class Scontrino {
  
  //numero progressivo
  private static int numeroMax = 0;
  private final int numero;
  private final Date data;
  private final HashSet<TipoLinkComprende> insiemeSouvenir;

  public Scontrino() {
    numero = (++numeroMax);
    data = new Date();
    insiemeSouvenir = new HashSet<TipoLinkComprende>();
  }

  public int getNumero() {
    return numero;
  }

  public Date getData() {
    return data;
  }

  public float totale() {
    float importo = 0;
    /* DA COMPLETARE A CURA DELLO STUDENTE */
    /* Il metodo deve restituire l'importo totale dello scontrino */
    
    return (importo);
  }

  public void inserisciLinkComprende(TipoLinkComprende t) {
    if (t != null && t.getScontrino() == this)
      ManagerComprende.inserisci(t);
  }

  public void inserisciLinkPerManagerComprende(ManagerComprende k) {
    if (k != null)
      insiemeSouvenir.add(k.getLink());
  }

  public void eliminaLinkComprende(TipoLinkComprende t) {
    if (t != null && t.getScontrino() == this)
      ManagerComprende.elimina(t);
  }

  public void eliminaLinkPerManagerComprende(ManagerComprende k) {
    if (k != null)
      insiemeSouvenir.remove(k.getLink());
  }

  @SuppressWarnings("unchecked")
  public Set<TipoLinkComprende> getLinkComprende() {
    return (HashSet<TipoLinkComprende>) insiemeSouvenir.clone();
  }

}
