package app.dominio;

public class ManagerComprende {
  
  private TipoLinkComprende link;
  
  private ManagerComprende(TipoLinkComprende x) {
    link = x;
  }

  public TipoLinkComprende getLink() {
    return link;
  }

  public static void inserisci(TipoLinkComprende y) {
    if (y != null) {
      /* DA COMPLETARE A CURA DELLO STUDENTE */
      
    }
  }

  public static void elimina(TipoLinkComprende y) {
    if (y != null) {
      /* DA COMPLETARE A CURA DELLO STUDENTE */
      
    }
  }

}
