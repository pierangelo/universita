package esercizio2;

public class Giudice implements Runnable {
  private Corsa corsa;

  public Giudice(Corsa unaCorsa) {
    this.corsa = unaCorsa;
  }

  public void run() {
    synchronized (corsa) {
      try {
        while (corsa.getVincitore() == null) {
          corsa.wait(); // rimane in attesa finche' non c'e' un vincitore
        }
        // ora c'e' un vincitore
        System.out.println("-------------- Ha vinto "
            + corsa.getVincitore() + " --------------");
      } catch (InterruptedException e) {
        e.printStackTrace();
        return;
      }
    }
  }
}
