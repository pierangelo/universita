package esercizio2;

public class Corridore implements Runnable {
  private final static int METRI = 100;
  private final String nome;
  private final Corsa corsa;
  private int spazio;

  public Corridore(Corsa unaCorsa, String nome) {
    this.corsa = unaCorsa;
    this.nome = nome;
    this.spazio = 0;
  }

  public void run() {
    try {
      while (spazio < METRI) {
        spazio++;
        Thread.sleep(5);
        System.out.println(nome + " ha percorso " + spazio + " metri");
      }
    }
    catch (InterruptedException err) {
      err.printStackTrace();
    }
    corsa.setArrivato(this);
  }

  public String getNome() {
    return nome;
  }

}
