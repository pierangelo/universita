package esercizio2;

import javax.swing.JOptionPane;

public class Application {

  public static void main(String[] args) {
    boolean corretto = false;
    int numCorridori = 0;
    while (!corretto) {
      try {
        numCorridori = Integer.parseInt(JOptionPane
            .showInputDialog("Inserisci il numero di corridori"));
        if (numCorridori > 0)
          corretto = true;
        else
          JOptionPane.showMessageDialog(null, "Inserire un numero maggiore di 0!",
              "Errore!", JOptionPane.ERROR_MESSAGE);
      }
      catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Inserire un numero intero!",
            "Errore!", JOptionPane.ERROR_MESSAGE);
      }
    }
    
    Thread[] threadCorridori = new Thread[numCorridori];
    Corsa corsa = new Corsa();

    for (int i = 0; i < numCorridori; i++) {
      // crea un thread per ciascun corridore e lo avvia
      // i thread vengono memorizzati in un vettore per la sincronizzazione
      // futura
      threadCorridori[i] = new Thread(new Corridore(corsa, i + ""));
      threadCorridori[i].start();
    }

    // Crea un nuovo thread per il giudice e lo fa partire.
    // Il thread "main" si ferma in attesa che il giudice abbia terminato
    // l'esecuzione.
    Thread giudice = new Thread(new Giudice(corsa));
    giudice.start();
    try {
      // main attende che il giudice abbia dichiarato il vincitore
      giudice.join();

      // main attende che tutti i corridori abbiano terminato la corsa
      for (int i = 0; i < numCorridori; i++) {
        threadCorridori[i].join();
      }
    }
    catch (InterruptedException e) {
      e.printStackTrace();
    }

    System.out.println(corsa); // Stampa la classifica
  }
}
