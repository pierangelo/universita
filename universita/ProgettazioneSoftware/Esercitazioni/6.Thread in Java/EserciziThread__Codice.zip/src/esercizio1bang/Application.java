package esercizio1bang;

import java.lang.Thread;

import javax.swing.JOptionPane;

public class Application {

  public static void main(String[] args) {
    boolean corretto = false;
    int numCorridori = 0;
    while (!corretto) {
      try {
        numCorridori = Integer.parseInt(JOptionPane
            .showInputDialog("Inserisci il numero di corridori"));
        if (numCorridori > 0)
          corretto = true;
        else
          JOptionPane.showMessageDialog(null, "Inserire un numero maggiore di 0!",
              "Errore!", JOptionPane.ERROR_MESSAGE);
      }
      catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Inserire un numero intero!",
            "Errore!", JOptionPane.ERROR_MESSAGE);
      }
    }
    // memorizza il numero di corridori pronti a partire
    ContatoreSincronizzato contatore = new ContatoreSincronizzato(numCorridori);
    Bang bang = new Bang();
    try {
      for (int i = 0; i < numCorridori; i++) {// fa partire tutti i corridori
        Thread t = new Thread(new Corridore("corridore " + i, contatore, bang));
        t.start();
      }

      // Attende che tutti i corridori siano pronti (cioe' ciascuno e'
      // all'inizio della propria iterazione)
      contatore.attendiCompletamento();

      System.out.println("\n----- Corridori pronti a partire -----\n");

      // Notifica a tutti i corridori che possono partire
      System.out.println("\n----- BANG! -----\n");
      Thread.sleep(300);// Solo per dare il tempo di leggere l'output
      bang.spara();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
}
