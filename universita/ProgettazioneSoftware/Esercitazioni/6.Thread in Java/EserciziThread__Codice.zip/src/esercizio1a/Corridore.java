package esercizio1a;

public class Corridore implements Runnable {
  private final String nome;
  private final static int METRI = 100;

  public Corridore(String nome) {
    this.nome = nome;
  }

  public void run() {
    int spazio = 0;
    try {
      while (spazio < METRI) {
        spazio++;
        Thread.sleep(10);
        System.out.println(nome + " " + spazio + " metri");
      }
    } catch (InterruptedException err) {
      err.printStackTrace();
    }
    System.out.println("Il corridore " + nome + " e' arrivato");
  }

  public String getNome() {
    return nome;
  }

}
