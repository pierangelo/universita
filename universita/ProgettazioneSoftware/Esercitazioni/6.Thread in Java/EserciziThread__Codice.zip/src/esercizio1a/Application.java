package esercizio1a;

import java.lang.Thread;
import javax.swing.JOptionPane;

public class Application {

  public static void main(String[] args) {
    boolean corretto = false;
    int numCorridori = 0;
    while (!corretto) {
      try {
        numCorridori = Integer.parseInt(JOptionPane
            .showInputDialog("Inserisci il numero di corridori"));
        if (numCorridori > 0)
          corretto = true;
        else
          JOptionPane.showMessageDialog(null, "Inserire un numero maggiore di 0!",
              "Errore!", JOptionPane.ERROR_MESSAGE);
      }
      catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Inserire un numero intero!",
            "Errore!", JOptionPane.ERROR_MESSAGE);
      }
    }
    for (int i = 0; i < numCorridori; i++) {
      Thread t = new Thread(new Corridore("corridore " + i));
      t.start();
    }
  }
}
