package app.dominio;

public class ManagerVince {

	private TipoLinkVince link;

	private ManagerVince(TipoLinkVince link) {
		this.link = link;
	}

	public TipoLinkVince getLink() {
		return link;
	}

	public static void inserisci(TipoLinkVince l) {
		/* DA COMPLETARE A CURA DELLO STUDENTE */
		
		
	}

	public static void elimina(TipoLinkVince l) {
		/* DA COMPLETARE A CURA DELLO STUDENTE */
		
		
	}
	
}
