package app._gestioneeventi;

public interface Listener {
  public void fired(Evento e); // dato un evento esegue la transizione
}