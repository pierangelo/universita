package app.dominio;

public class Ufficio extends Immobile {

	public Ufficio(int metriQuadri, int interno, int piano) {
		super(metriQuadri, interno, piano);
	}

}
