package app.dominio;

public final class ManagerSostiene {
	
	private final TipoLinkSostiene link;
	
	private ManagerSostiene(TipoLinkSostiene link) {
		this.link = link;
	}

	public TipoLinkSostiene getLink() {
		return link;
	}
	
	public static void inserisci(TipoLinkSostiene l) {
		/* DA COMPLETARE A CURA DELLO STUDENTE */
		
		
		
	}

	public static void elimina(TipoLinkSostiene l) {
		/* DA COMPLETARE A CURA DELLO STUDENTE */
		
		
		
	}

}
