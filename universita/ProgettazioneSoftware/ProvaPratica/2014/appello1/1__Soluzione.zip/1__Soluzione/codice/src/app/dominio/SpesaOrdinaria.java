package app.dominio;

public class SpesaOrdinaria extends Spesa {

	public SpesaOrdinaria(String codice, double importo, int anno, String descrizione) {
		super(codice, importo, anno, descrizione);
	}

	

}
