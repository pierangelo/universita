package app._framework;

public interface Task {
	public void esegui(Executor e);
}